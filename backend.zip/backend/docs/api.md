# TeamChatX API Handbook (Complete)

Last updated: 2026-02-27

## 1. Basics

- Base URL: `http://localhost:5000`
- Content type: `application/json`
- Auth header:

```text
Authorization: Bearer <access_token>
```

Response format:

```json
{
  "status": "success",
  "message": "Human readable message",
  "data": {}
}
```

```json
{
  "status": "error",
  "message": "Human readable message",
  "errors": null
}
```

## 2. Access Control

Roles used by middleware:

- `role_id = 1`: owner-level write access on master resources
- `role_id = 4`: blocked for restricted routes

Owner-only write resources additionally include:

- `/plan-features` (`POST`, `PUT`, `PATCH`)
- `/product-features` (`POST`, `PUT`, `PATCH`)
- `/product-features/categories` (`POST`, `PUT`, `PATCH`)

Access legend:

- `Public`: no JWT
- `JWT`: JWT required
- `Owner`: JWT + `role_id=1`
- `Blocked role 4`: JWT allowed for others but role 4 denied

## 3. Middleware Pipeline

App middleware order (`src/app.js`):

1. `helmet`
2. `cors`
3. `express.json`
4. `express.urlencoded`
5. `morgan` (except test)
6. route handlers
7. not found handler
8. `errorHandler`

Route-level middleware shortcuts:

- `auth`: JWT verification
- `requireOwner`: only `role_id=1`
- `blockRole4`: `requireNotRoleId(4)`

## 4. Full Endpoint Inventory

## 4.1 Health

| Method | Endpoint    | Access | Middleware |
| ------ | ----------- | ------ | ---------- |
| GET    | `/health` | Public | none       |

## 4.2 Auth (`/auth`)

| Method | Endpoint                       | Access         | Middleware             |
| ------ | ------------------------------ | -------------- | ---------------------- |
| POST   | `/auth/register`             | Public         | none                   |
| POST   | `/auth/create-account`       | Public         | none                   |
| POST   | `/auth/resend-otp`           | Public         | none                   |
| POST   | `/auth/forgot-password`      | Public         | none                   |
| POST   | `/auth/reset-password`       | Public         | none                   |
| POST   | `/auth/forgot-verify`        | Public         | none                   |
| POST   | `/auth/verify-otp`           | Public         | none                   |
| POST   | `/auth/login`                | Public         | none                   |
| POST   | `/auth/refresh`              | Public         | none                   |
| POST   | `/auth/logout`               | Public         | none                   |
| GET    | `/auth/me`                   | JWT            | `auth`               |
| GET    | `/auth/user-details`         | Blocked role 4 | `auth -> blockRole4` |
| POST   | `/auth/user-details`         | Blocked role 4 | `auth -> blockRole4` |
| GET    | `/auth/organization-details` | Blocked role 4 | `auth -> blockRole4` |

## 4.3 Users (`/users`)

| Method | Endpoint                   | Access         | Middleware                                             |
| ------ | -------------------------- | -------------- | ------------------------------------------------------ |
| POST   | `/users/forgot-password` | Public         | none                                                   |
| POST   | `/users/forgot-verify`   | Public         | none                                                   |
| GET    | `/users`                 | Blocked role 4 | `auth -> blockRole4`                                 |
| POST   | `/users`                 | Blocked role 4 | `auth -> blockRole4 -> validateCreateOrgUser`        |
| PATCH  | `/users/bulk`            | Blocked role 4 | `auth -> blockRole4 -> validateBulkUpdateOrgUsers`   |
| POST   | `/users/reset-password`  | Blocked role 4 | `auth -> blockRole4 -> validateResetOrgUserPassword` |
| GET    | `/users/:id`             | Blocked role 4 | `auth -> blockRole4`                                 |
| PUT    | `/users/:id`             | Blocked role 4 | `auth -> blockRole4 -> validateUpdateOrgUser`        |
| PATCH  | `/users/:id`             | Blocked role 4 | `auth -> blockRole4 -> validateUpdateOrgUser`        |
| DELETE | `/users/:id`             | Blocked role 4 | `auth -> blockRole4`                                 |
| PATCH  | `/users/:id/deactivate`  | Blocked role 4 | `auth -> blockRole4`                                 |
| PATCH  | `/users/:id/activate`    | Blocked role 4 | `auth -> blockRole4`                                 |

## 4.4 Global Access (`/global-access`)

| Method | Endpoint                         | Access         | Middleware                                           |
| ------ | -------------------------------- | -------------- | ---------------------------------------------------- |
| GET    | `/global-access`               | JWT            | `auth`                                             |
| POST   | `/global-access`               | Blocked role 4 | `auth -> blockRole4 -> validateCreateGlobalAccess` |
| GET    | `/global-access/allowed-users` | JWT            | `auth`                                             |
| GET    | `/global-access/:id`           | JWT            | `auth`                                             |
| PUT    | `/global-access/:id`           | Blocked role 4 | `auth -> blockRole4 -> validatePutGlobalAccess`    |
| PATCH  | `/global-access/:id`           | Blocked role 4 | `auth -> blockRole4 -> validatePatchGlobalAccess`  |
| DELETE | `/global-access/:id`           | Blocked role 4 | `auth -> blockRole4`                               |

## 4.5 Organization Structure

Departments (`/departments`), Designations (`/designations`), Locations (`/locations`):

- all methods are `Blocked role 4`
- middleware pattern:
  - read: `auth -> blockRole4`
  - write: `auth -> blockRole4 -> validate*`

## 4.6 Master Resources

Resources:

- `/roles`
- `/plans`
- `/languages`
- `/timezones`
- `/platforms`
- `/message-menu-items`

Method contract:

- `GET /resource`, `GET /resource/:id`: `JWT`, middleware `auth`
- `POST/PUT/PATCH/DELETE`: `Owner`, middleware `auth -> requireOwner -> validate* -> ensureUnique*`

## 4.7 Activity Logs

| Method | Endpoint           | Access         | Middleware             |
| ------ | ------------------ | -------------- | ---------------------- |
| GET    | `/activity-logs` | Blocked role 4 | `auth -> blockRole4` |

## 4.8 Groups (`/groups`)

| Method | Endpoint        | Access         | Middleware                                     |
| ------ | --------------- | -------------- | ---------------------------------------------- |
| GET    | `/groups`     | JWT            | `auth`                                         |
| POST   | `/groups`     | Blocked role 4 | `auth -> blockRole4 -> validateGroupPayload` |
| GET    | `/groups/:id` | JWT            | `auth`                                         |
| PUT    | `/groups/:id` | Blocked role 4 | `auth -> blockRole4 -> validateGroupPut`     |
| PATCH  | `/groups/:id` | Blocked role 4 | `auth -> blockRole4 -> validateGroupPatch`   |

## 4.9 Group Members (`/group-members`)

| Method | Endpoint                         | Access         | Middleware                                          |
| ------ | -------------------------------- | -------------- | --------------------------------------------------- |
| GET    | `/group-members`               | JWT            | `auth`                                              |
| GET    | `/group-members/by-group-name` | JWT            | `auth`                                              |
| GET    | `/group-members/:id`           | JWT            | `auth`                                              |
| POST   | `/group-members`               | Blocked role 4 | `auth -> blockRole4 -> validateCreateGroupMember` |
| PUT    | `/group-members/:id`           | Blocked role 4 | `auth -> blockRole4 -> validatePutGroupMember`    |
| PATCH  | `/group-members/:id`           | Blocked role 4 | `auth -> blockRole4 -> validatePatchGroupMember`  |

## 4.10 Group Timeline (`/group-timeline`)

| Method | Endpoint            | Access | Middleware |
| ------ | ------------------- | ------ | ---------- |
| GET    | `/group-timeline` | JWT    | `auth`     |

## 4.11 Organization Message Menu Permissions (`/organization-message-menu-permissions`)

| Method | Endpoint                                       | Access         | Middleware                                         |
| ------ | ---------------------------------------------- | -------------- | -------------------------------------------------- |
| GET    | `/organization-message-menu-permissions`     | Blocked role 4 | `auth -> blockRole4`                             |
| POST   | `/organization-message-menu-permissions`     | Blocked role 4 | `auth -> blockRole4 -> validateCreatePermission` |
| GET    | `/organization-message-menu-permissions/:id` | Blocked role 4 | `auth -> blockRole4`                             |
| PUT    | `/organization-message-menu-permissions/:id` | Blocked role 4 | `auth -> blockRole4 -> validatePutPermission`    |
| PATCH  | `/organization-message-menu-permissions/:id` | Blocked role 4 | `auth -> blockRole4 -> validatePatchPermission`  |

## 4.12 Plan Features (`/plan-features`)

| Method | Endpoint                                | Access | Middleware                                                                       |
| ------ | --------------------------------------- | ------ | -------------------------------------------------------------------------------- |
| GET    | `/plan-features/plan/:planId/summary` | JWT    | `auth`                                                                         |
| GET    | `/plan-features`                      | JWT    | `auth`                                                                         |
| POST   | `/plan-features`                      | Owner  | `auth -> requireOwner -> validateCreatePlanFeature -> ensureUniquePlanFeature` |
| GET    | `/plan-features/:id`                  | JWT    | `auth`                                                                         |
| PUT    | `/plan-features/:id`                  | Owner  | `auth -> requireOwner -> validateUpdatePlanFeature -> ensureUniquePlanFeature` |
| PATCH  | `/plan-features/:id`                  | Owner  | `auth -> requireOwner -> validateUpdatePlanFeature -> ensureUniquePlanFeature` |

## 4.13 Site Details (`/site-details`)

| Method | Endpoint              | Access | Middleware                                           |
| ------ | --------------------- | ------ | ---------------------------------------------------- |
| GET    | `/site-details`     | Public | none                                                 |
| GET    | `/site-details/:id` | Public | none                                                 |
| POST   | `/site-details`     | Owner  | `auth -> requireOwner -> validateCreateSiteDetail` |
| PUT    | `/site-details/:id` | Owner  | `auth -> requireOwner -> validateUpdateSiteDetail` |
| PATCH  | `/site-details/:id` | Owner  | `auth -> requireOwner -> validatePatchSiteDetail`  |

## 4.14 Product Features (`/product-features`)

| Method | Endpoint                                     | Access | Middleware                                                                                                 |
| ------ | -------------------------------------------- | ------ | ---------------------------------------------------------------------------------------------------------- |
| GET    | `/product-features/catalog`                | JWT    | `auth`                                                                                                   |
| GET    | `/product-features/categories`             | JWT    | `auth`                                                                                                   |
| POST   | `/product-features/categories`             | Owner  | `auth -> requireOwner -> validateCreateCategory -> ensureUniqueCategoryKey`                              |
| GET    | `/product-features/categories/:categoryId` | JWT    | `auth`                                                                                                   |
| PUT    | `/product-features/categories/:categoryId` | Owner  | `auth -> requireOwner -> validatePutCategory -> ensureUniqueCategoryKey`                                 |
| PATCH  | `/product-features/categories/:categoryId` | Owner  | `auth -> requireOwner -> validatePatchCategory -> ensureUniqueCategoryKey`                               |
| GET    | `/product-features`                        | JWT    | `auth`                                                                                                   |
| POST   | `/product-features`                        | Owner  | `auth -> requireOwner -> validateCreateItem -> ensureCategoryExists -> ensureUniqueItemTitlePerCategory` |
| GET    | `/product-features/:id`                    | JWT    | `auth`                                                                                                   |
| PUT    | `/product-features/:id`                    | Owner  | `auth -> requireOwner -> validatePutItem -> ensureCategoryExists -> ensureUniqueItemTitlePerCategory`    |
| PATCH  | `/product-features/:id`                    | Owner  | `auth -> requireOwner -> validatePatchItem -> ensureCategoryExists -> ensureUniqueItemTitlePerCategory`  |

## 4.15 Contact Us (`/contact-us`)

| Method | Endpoint            | Access         | Middleware                       |
| ------ | ------------------- | -------------- | -------------------------------- |
| POST   | `/contact-us`     | Public         | `validateCreateContactRequest` |
| GET    | `/contact-us`     | Blocked role 4 | `auth -> blockRole4`           |
| GET    | `/contact-us/:id` | Blocked role 4 | `auth -> blockRole4`           |

## 4.16 Organization Restrictions (`/organization-restrictions`)

| Method | Endpoint                                    | Access         | Middleware                                                  |
| ------ | ------------------------------------------- | -------------- | ----------------------------------------------------------- |
| GET    | `/organization-restrictions/ip`           | JWT            | `auth`                                                    |
| GET    | `/organization-restrictions/ip/:id`       | JWT            | `auth`                                                    |
| POST   | `/organization-restrictions/ip`           | Blocked role 4 | `auth -> blockRole4 -> validateCreateIpRestriction`       |
| PUT    | `/organization-restrictions/ip/:id`       | Blocked role 4 | `auth -> blockRole4 -> validatePutIpRestriction`          |
| PATCH  | `/organization-restrictions/ip/:id`       | Blocked role 4 | `auth -> blockRole4 -> validatePatchIpRestriction`        |
| GET    | `/organization-restrictions/platform`     | JWT            | `auth`                                                    |
| GET    | `/organization-restrictions/platform/:id` | JWT            | `auth`                                                    |
| POST   | `/organization-restrictions/platform`     | Blocked role 4 | `auth -> blockRole4 -> validateCreatePlatformRestriction` |
| PUT    | `/organization-restrictions/platform/:id` | Blocked role 4 | `auth -> blockRole4 -> validatePutPlatformRestriction`    |
| PATCH  | `/organization-restrictions/platform/:id` | Blocked role 4 | `auth -> blockRole4 -> validatePatchPlatformRestriction`  |

## 5. Validation Rules (Exact Middleware Rules)

## 5.1 `/users` validation

`validateCreateOrgUser`:

- required: `name`, `email`
- `email` valid format
- optional numeric positive: `role_id`, `department_id`, `designation_id`, `location_id`

`validateUpdateOrgUser`:

- at least one field required
- allowed fields:
  - `name`, `email`, `mobile`, `role_id`, `is_platform_admin`, `is_global_member`
  - `user_status`, `membership_status`
  - `department_id`, `designation_id`, `location_id`
- `email` format valid
- `role_id`, `department_id`, `designation_id`, `location_id` positive
- `user_status` in: `active|suspended|invited|archived`
- `membership_status` in: `active|invited|suspended|left`

`validateBulkUpdateOrgUsers`:

- `updates` array required
- each item needs valid `user_id`
- at least one update field per item
- same allowed fields/rules as update

`validateResetOrgUserPassword`:

- required: `email`
- valid email format
- optional `new_password` min length 8

## 5.2 `/global-access` validation

`validateCreateGlobalAccess` and `validatePutGlobalAccess`:

- required: `user_id`, `allow_user_id`
- both positive numbers
- both must be different
- optional `status` in: `active|inactive`

`validatePatchGlobalAccess`:

- at least one of `user_id`, `allow_user_id`, `status`
- numeric/status rules same as above
- `user_id` and `allow_user_id` cannot be equal

## 5.3 Master resource validators

Roles:

- create required: `role_key`, `role_name`
- optional `status`: `active|inactive`
- unique key check: `role_key`

Plans:

- create required: `plan_key`, `plan_name`, `interval_days`
- `interval_days` positive
- optional `status`: `active|inactive`
- unique key check: `plan_key`

Languages:

- create required: `language_code`, `full_name`, `native_name`
- optional `direction`: `ltr|rtl`
- optional `status`: `active|inactive`
- unique key check: `language_code`

Timezones:

- create required: `timezone_code`, `display_name`, `utc_offset`
- optional `status`: `active|inactive`
- unique key check: `timezone_code`

Platforms:

- create required: `platform_key`, `platform_name`
- optional `category`: `browser|os|device|other`
- unique key check: `platform_key`

Message menu items:

- create required: `menu_key`, `label`
- optional `default_status`: `show|hide|disable`
- optional `scope`: `any|self|admin`
- optional `tone`: `normal|danger|warning|info`
- unique key check: `menu_key`

## 5.4 Organization structure validators

Departments:

- create required: `organization_id`, `name`
- optional `status`: `active|inactive`

Designations:

- create required: `organization_id`, `department_id`, `name`
- optional `status`: `active|inactive`

Locations:

- create required: `organization_id`, `label`
- optional `status`: `active|inactive`

## 5.5 Group validators

Groups:

- create required: `group_name`
- put required: `group_name`
- optional `organization_id` (if missing, token org default is used in controller)
- optional `status`: `active|inactive|archived|deleted`
- optional `is_airtime`: boolean
- `group_name` must be unique per `organization_id` (case-insensitive, trimmed)

Group members:

- create required: `group_id`, `user_id`
- optional `organization_id` (if missing, token org default is used in controller)
- optional `status`: `active|left|kicked|banned`
- optional `is_admin`: boolean
- write integrity checks:
  - `group_id` must belong to same `organization_id`
  - `user_id` must be active organization member in same org

## 5.6 Organization message menu permission validators

Create (`validateCreatePermission`):

- required: `menu_item_id`
- optional `permission_type`: `show|hide|disable`
- optional `status`: `active|inactive`

Put (`validatePutPermission`):

- required: `menu_item_id`
- required `permission_type`: `show|hide|disable`
- optional `status`: `active|inactive`

Patch (`validatePatchPermission`):

- at least one field: `menu_item_id`, `permission_type`, `note`, `status`
- `permission_type` in: `show|hide|disable`
- `status` in: `active|inactive`

## 5.7 Plan feature validators

Create (`validateCreatePlanFeature`):

- required: `plan_id`, `feature_name`
- optional `display_order` must be integer
- optional `status`: `active|inactive`

Update (`validateUpdatePlanFeature`):

- optional `plan_id` must be positive
- optional `feature_name` cannot be empty
- optional `display_order` must be integer
- optional `status`: `active|inactive`

Uniqueness (`ensureUniquePlanFeature`):

- `feature_name` must be unique per `plan_id`

## 5.8 Site details validators

Create (`validateCreateSiteDetail`):

- required: `brand_name`
- optional: `logo_url`, `mascot_url`, `google_plus_url`, `linkedin_url`, `twitter_url`, `youtube_url`
- optional `status`: `active|inactive`
- optional arrays: `emails`, `phones`, `addresses`

Update (`validateUpdateSiteDetail`):

- same rules as create (`brand_name` required)
- replaces provided arrays fully

Patch (`validatePatchSiteDetail`):

- at least one field required
- supports partial updates for top-level fields and arrays

Array item rules:

- `emails[]`: `email_address` required, optional `label`, optional `is_primary`, optional `status`
- `phones[]`: `phone_number` required, optional `label`, optional `is_primary`, optional `status`
- `addresses[]`: `address_line_1` required, optional `label`, `address_line_2`, `city`, `state`, `country`, `postal_code`, `is_primary`, `status`
- each array can have at most one `is_primary=true`

## 5.9 Product features validators

Category create (`validateCreateCategory`) and put (`validatePutCategory`):

- required: `category_key`, `category_label`
- optional: `display_order` positive integer
- optional: `status` in `active|inactive`

Category patch (`validatePatchCategory`):

- at least one field required
- allowed: `category_key`, `category_label`, `display_order`, `status`

Item create (`validateCreateItem`) and put (`validatePutItem`):

- required: `feature_category_id`, `title`
- optional: `description`, `icon_url`
- optional: `display_order` positive integer
- optional: `status` in `active|inactive`

Item patch (`validatePatchItem`):

- at least one field required
- allowed: `feature_category_id`, `title`, `description`, `icon_url`, `display_order`, `status`

Uniqueness/integrity:

- `ensureUniqueCategoryKey`: `category_key` unique
- `ensureCategoryExists`: `feature_category_id` must exist
- `ensureUniqueItemTitlePerCategory`: `title` unique per `feature_category_id`

## 5.10 Contact us validators

Create (`validateCreateContactRequest`):

- required: `name`, `mobile_number`, `email_address`, `company_name`, `total_users`
- optional: `country_code` (default `+91`), `requirement_details`
- `email_address` valid format
- `total_users` positive integer

## 6. Detailed API Contracts + Examples

## 6.1 Auth APIs

### `POST /auth/create-account`

Purpose: create owner user + organization + member + subscription + verification OTP.

Request:

```json
{
  "company_name": "Acme Pvt Ltd",
  "owner_name": "Rohit Sharma",
  "email": "rohit@acme.com",
  "phone": "+919876543210",
  "password": "StrongPass123"
}
```

### `POST /auth/verify-otp`

```json
{
  "email": "rohit@acme.com",
  "otp_code": "123456"
}
```

### `POST /auth/forgot-password`

```json
{
  "email": "rohit@acme.com"
}
```

### `POST /auth/forgot-verify`

```json
{
  "email": "rohit@acme.com",
  "otp_code": "123456"
}
```

Success response includes `reset_token` and `reset_link`.

Invalid OTP response (HTTP `200`, business error payload):

```json
{
  "status": "error",
  "message": "Invalid OTP. Attempt 1/5. 4 attempts left",
  "errors": {
    "attempt_number": 1,
    "max_attempts": 5,
    "attempts_left": 4
  }
}
```

### `POST /auth/reset-password`

```json
{
  "reset_token": "<reset_token>",
  "new_password": "NewStrongPass123"
}
```

### `POST /auth/login`

```json
{
  "email": "rohit@acme.com",
  "password": "StrongPass123",
  "device_name": "Rohit Laptop",
  "device_type": "desktop",
  "latitude": 28.6139,
  "longitude": 77.209,
  "country": "IN",
  "city": "Delhi"
}
```

### `POST /auth/refresh`

```json
{
  "refresh_token": "<refresh_token>"
}
```

### `POST /auth/logout`

```json
{
  "refresh_token": "<refresh_token>"
}
```

### `GET /auth/me?limit=25`

Purpose: expanded profile response (user + org + membership + plan + usage + counts + lists).

### `GET /auth/user-details`

Query/body options:

- `email` optional
- `full` optional (`true|false`)
- `limit` optional

### `GET /auth/organization-details?organization_id=2`

Returns:

- organization
- owner
- current_plan
- usage
- counts
- role_distribution

Example response snippet:

```json
{
  "status": "success",
  "message": "Organization details retrieved",
  "data": {
    "organization": {
      "organization_id": 2,
      "name": "Demo Org"
    },
    "usage": {
      "storage_used_mb": 256,
      "storage_limit_mb": 2048,
      "storage_usage_percent": 12.5
    },
    "counts": {
      "total_members": 12,
      "active_members": 10
    }
  }
}
```

## 6.2 User APIs (`/users`)

### `POST /users`

```json
{
  "organization_id": 2,
  "name": "Amit",
  "email": "amit@vedsu.com",
  "mobile": "9999999999",
  "role_id": 4,
  "department_id": 2,
  "designation_id": 2,
  "location_id": 1,
  "is_platform_admin": false,
  "is_global_member": true
}
```

Default role behavior:

- if `role_id` missing and `is_platform_admin=true` -> role `2`
- if `role_id` missing and `is_platform_admin=false` -> role `4`

### `GET /users?organization_id=2&search=amit&limit=20&offset=0`

Returns paginated organization users.

### `PUT/PATCH /users/:id`

```json
{
  "role_id": 3,
  "department_id": 2,
  "designation_id": 2,
  "location_id": 1,
  "membership_status": "active"
}
```

### `PATCH /users/bulk`

```json
{
  "updates": [
    {
      "user_id": 9,
      "role_id": 3,
      "department_id": 2,
      "designation_id": 2,
      "location_id": 1
    }
  ]
}
```

### `POST /users/reset-password`

```json
{
  "organization_id": 2,
  "email": "amar@vedsu.com",
  "new_password": "NewStrongPass123"
}
```

## 6.3 Master APIs (role/plan/language/timezone/platform/menu item)

Resource pattern:

- list: `GET /resource?search=&limit=&offset=`
- create: `POST /resource`
- single: `GET /resource/:id`
- update: `PUT /resource/:id`
- patch: `PATCH /resource/:id`
- delete: `DELETE /resource/:id`

Create example (`POST /roles`):

```json
{
  "role_key": "manager",
  "role_name": "Manager",
  "description": "Manager role",
  "status": "active"
}
```

Create example (`POST /plans`):

```json
{
  "plan_key": "growth",
  "plan_name": "Growth",
  "price": 1999,
  "interval_days": 30,
  "max_users": 100,
  "max_storage_mb": 4096,
  "status": "active"
}
```

## 6.4 Organization Structure APIs

Department create:

```json
{
  "organization_id": 2,
  "name": "HR",
  "status": "active"
}
```

Designation create:

```json
{
  "organization_id": 2,
  "department_id": 2,
  "name": "Manager",
  "status": "active"
}
```

Location create:

```json
{
  "organization_id": 2,
  "label": "Delhi HQ",
  "status": "active"
}
```

## 6.5 Global Access APIs

Purpose:

- map one global member user to allowed users in same org
- table fields: `org_id`, `user_id`, `allow_user_id`, `status`

DB integrity rules:

- `user_id` must be global member (`users.is_global_member=true`)
- `allow_user_id` must exist
- `allow_user_id` must belong to same `org_id`
- cross-organization mapping blocked

### Create (`POST /global-access`)

```json
{
  "org_id": 2,
  "user_id": 9,
  "allow_user_id": 12,
  "status": "active"
}
```

### Update full (`PUT /global-access/5`)

```json
{
  "org_id": 2,
  "user_id": 9,
  "allow_user_id": 15,
  "status": "active"
}
```

### Patch (`PATCH /global-access/5`)

```json
{
  "status": "inactive"
}
```

### Delete URL

```text
/global-access/5?org_id=2
```

### Allowed users fetch

```text
/global-access/allowed-users?org_id=2&user_id=9
```

## 6.6 Activity Logs API

`GET /activity-logs` query params:

- `organization_id`
- `user_id`
- `actor_id`
- `action`
- `status` (`success|failed|denied`)
- `is_successful` (`true|false`)
- `occurred_from`
- `occurred_to`
- `search`
- `limit`
- `offset`

## 6.7 Groups API

### Create (`POST /groups`)

```json
{
  "group_name": "Aabhyasa Development",
  "group_description": "Main dev group",
  "group_image": null,
  "is_airtime": false,
  "status": "active"
}
```

Notes:

- `organization_id` optional in write payload, defaults from token org.
- timeline event auto-created: `group_created`.
- duplicate `group_name` in same organization is blocked (`409`).

### Update full (`PUT /groups/:id`)

```json
{
  "group_name": "Aabhyasa Development Team",
  "group_description": "Updated by PUT",
  "group_image": "https://example.com/group.png",
  "is_airtime": true,
  "status": "active"
}
```

### Patch (`PATCH /groups/:id`)

```json
{
  "group_description": "Updated by PATCH"
}
```

## 6.8 Group Members API

### Create (`POST /group-members`)

```json
{
  "group_id": 1,
  "user_id": 5,
  "is_admin": false,
  "status": "active"
}
```

### Update full (`PUT /group-members/:id`)

```json
{
  "group_id": 1,
  "user_id": 5,
  "is_admin": true,
  "status": "active"
}
```

### Patch (`PATCH /group-members/:id`)

```json
{
  "status": "left"
}
```

### List by group name

```text
/group-members/by-group-name?group_name=Aabhyasa%20Development&organization_id=2&status=active&limit=10&offset=0
```

Response row fields:

- `group_member_id`
- `group_id`
- `group_name`
- `organization_id`
- `user_id`
- `name`
- `email`
- `is_admin`
- `member_status`

## 6.9 Group Timeline API

```text
/group-timeline?group_id=1&organization_id=2&event_type=member_added&status=visible&limit=20&offset=0
```

Event types currently written by system:

- `group_created`
- `group_updated`
- `group_patched`
- `member_added`
- `member_updated`
- `member_patched`

## 6.10 Organization Message Menu Permissions API

List:

```text
/organization-message-menu-permissions?permission_type=hide&status=active&search=delete&limit=20&offset=0
```

Note:

- `organization_id` request me pass mat karo.
- Organization context login token (`req.user.org`) se auto pick hota hai.

Create (`POST /organization-message-menu-permissions`) body:

```json
{
  "menu_item_id": 5,
  "permission_type": "show",
  "note": "Default visible for managers",
  "status": "active"
}
```

PUT (`/organization-message-menu-permissions/:id`) body:

```json
{
  "menu_item_id": 5,
  "permission_type": "disable",
  "note": "Disabled by org policy",
  "status": "inactive"
}
```

PATCH (`/organization-message-menu-permissions/:id`) body:

```json
{
  "permission_type": "hide",
  "status": "active"
}
```

## 6.11 Plan Features API

List:

```text
/plan-features?plan_id=1&status=active&search=chat&limit=20&offset=0
```

Create (`POST /plan-features`) body:

```json
{
  "plan_id": 1,
  "feature_name": "One-One Messaging",
  "feature_description": "Direct secure one-to-one chat",
  "feature_icon": "chat",
  "section_label": "Plan Features",
  "display_order": 1,
  "status": "active"
}
```

Summary:

```text
/plan-features/plan/1/summary?status=all
```

Summary response includes:

- `plan` details
- `counts`: `total`, `active`, `inactive`, `filtered`
- `features` filtered by `status` (`all|active|inactive`)

## 6.12 Site Details API

Endpoints:

- `GET /site-details`
- `GET /site-details/:id`
- `POST /site-details` (`role_id=1` only)
- `PUT /site-details/:id` (`role_id=1` only)
- `PATCH /site-details/:id` (`role_id=1` only)

Access:

- `GET` endpoints are public.
- `POST/PUT/PATCH` require owner role (`role_id=1`).

PUT example:

```json
{
  "brand_name": "TeamChatX Global",
  "logo_url": "https://cdn.example.com/logo-new.png",
  "mascot_url": "https://cdn.example.com/mascot-new.png",
  "google_plus_url": null,
  "linkedin_url": "https://linkedin.com/company/teamchatx-global",
  "twitter_url": "https://x.com/teamchatxglobal",
  "youtube_url": "https://youtube.com/@teamchatxglobal",
  "status": "active",
  "emails": [
    {
      "email_address": "support@teamchatx.com",
      "label": "support",
      "is_primary": true,
      "status": "active"
    }
  ],
  "phones": [
    {
      "phone_number": "+919876543210",
      "label": "main",
      "is_primary": true,
      "status": "active"
    }
  ],
  "addresses": [
    {
      "label": "HQ",
      "address_line_1": "Sector 62",
      "city": "Noida",
      "state": "Uttar Pradesh",
      "country": "India",
      "postal_code": "201301",
      "is_primary": true,
      "status": "active"
    }
  ]
}
```

PATCH example:

```json
{
  "brand_name": "TeamChatX India",
  "twitter_url": "https://x.com/teamchatxindia"
}
```

## 6.13 Product Features API

Catalog:

```text
/product-features/catalog?status=active
```

Category create (`POST /product-features/categories`):

```json
{
  "category_key": "messaging",
  "category_label": "MESSAGING",
  "display_order": 1,
  "status": "active"
}
```

Feature item create (`POST /product-features`):

```json
{
  "feature_category_id": 1,
  "title": "One-On-One Messaging",
  "description": "A 1:1 message is brief and to the point.",
  "icon_url": "https://cdn.example.com/icons/one-on-one.svg",
  "display_order": 1,
  "status": "active"
}
```

PUT item (`PUT /product-features/:id`):

```json
{
  "feature_category_id": 1,
  "title": "Audio Messaging",
  "description": "Voice notes with preview and quick sharing.",
  "icon_url": "https://cdn.example.com/icons/audio.svg",
  "display_order": 2,
  "status": "active"
}
```

PATCH item (`PATCH /product-features/:id`):

```json
{
  "description": "Updated text from admin panel",
  "status": "active"
}
```

## 6.14 Contact Us API

Create request (`POST /contact-us`):

```json
{
  "name": "Ravi Kumar",
  "country_code": "+91",
  "mobile_number": "9876543210",
  "email_address": "ravi@example.com",
  "company_name": "Acme Pvt Ltd",
  "total_users": 120,
  "requirement_details": "Need secure team chat with admin controls."
}
```

Mail notification:

- on successful `POST /contact-us`, system sends 2 formatted mails:
- admin notification (`New Contact Us Request`) to `.env CONTACT_US_NOTIFY_TO` (recommended `support@teamchatx.com`)
- customer acknowledgement (`Thank you for contacting us`) to submitted `email_address`
- mails async/background me send hote hain for faster API response.
- templates intentionally concise hain (essential details only) for better readability.
- template location: `src/templates/mail/contactUs/*`

List (`GET /contact-us`) with filters:

```text
/contact-us?status=new&search=acme&limit=20&offset=0
```

## 7. Activity Log Actions in Use

Auth/user actions already logged include:

- `auth.create_account`
- `auth.resend_otp`
- `auth.forgot_password_otp`
- `auth.reset_password`
- `auth.verify_otp`
- `user.create`
- `user.update`
- `user.bulk_update`
- `user.soft_delete`
- `user.password_reset`
- `user.deactivate`
- `user.activate`

Global/organization actions:

- `global_access.create`
- `global_access.update`
- `global_access.patch`
- `global_access.delete`
- `organization.details.view`

Group actions (activity_log):

- `group.create`
- `group.update`
- `group.patch`
- `group_member.create`
- `group_member.update`
- `group_member.patch`

Organization message menu permission actions (activity_log):

- `organization_message_menu_permission.create`
- `organization_message_menu_permission.update`
- `organization_message_menu_permission.patch`

Plan feature actions (activity_log):

- `plan_feature.create`
- `plan_feature.update`
- `plan_feature.patch`

Group actions (group timeline):

- `group_created`
- `group_updated`
- `group_patched`
- `member_added`
- `member_updated`
- `member_patched`

## 8. Common Errors

- `Unauthorized` (401): missing/invalid token
- `Invalid token` (401)
- `Access denied` (403): role-based restriction
- `Access denied for requested organization` (403): org membership restriction
- `Global access mapping already exists` (409)
- `Invalid allow_user_id: user does not exist` (400)
- `Invalid allow_user_id: user does not belong to the requested organization` (400)
- `Invalid user_id: global member user does not exist` (400)
- `Invalid org_id: organization does not exist` (400)
- `organization_id is required (body or login token org)` (400)
- `organization_id must match the group organization` (400)
- `user_id is not an active member of this organization` (400)
- `Cannot add member: group is not active` (400)
- `User is already a member of this group` (409)
- `group_name query is required` (400)
- `Group name already exists in this organization` (409)
- `Invalid OTP. Attempt X/5. Y attempts left` (HTTP 200 with `status=error`)
- `Maximum OTP attempts reached. Contact support for reset password.` (HTTP 200 with `status=error`)

## 9. Related Docs

- `docs/documentation.md`: behavior-focused detailed documentation
- `docs/api.md`: this complete endpoint handbook
- `docs/database.md`: schema and constraints
- `docs/query.md`: SQL query packs
- `docs/command.md`: psql commands

## Update Log (2026-02-25)

- Contact Us dual-mail behavior documented with async dispatch.
- Mail template source paths documented under `src/templates/mail/*`.
- Site Details and Product Features access rules revalidated.
- Organization Restrictions endpoint matrix added with role-based write blocking for `role_id=4`.
- Restriction write actions log to `activity_log` with actor and old/new values.
