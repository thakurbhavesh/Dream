# Database Migration Guide

Last updated: 2026-02-27

This page explains how to run SQL migrations from the `migrations/` folder.

## Prerequisites

- PostgreSQL installed and running
- Database created (example: `teamChatx`)
- `psql` command available in terminal

Optional env vars used below:
- `DB_HOST`
- `DB_PORT`
- `DB_USER`
- `DB_NAME`
- `DB_PASSWORD` (set as `PGPASSWORD`)

## Migration Files (Current Order)

Run in this exact order:

1. `migrations/001_init.sql`
2. `migrations/002_org_members_department_designation.sql`
3. `migrations/003_org_members_location.sql`
4. `migrations/004_activity_log.sql`
5. `migrations/005_global_access.sql`
6. `migrations/006_global_access_allow_user_org_scope.sql`
7. `migrations/007_performance_indexes.sql`
8. `migrations/008_activity_log_query_optimizations.sql`
9. `migrations/009_groups_and_related_tables.sql`
10. `migrations/010_group_members_timeline_perf.sql`
11. `migrations/011_groups_lookup_indexes.sql`
12. `migrations/012_api_hotpath_indexes.sql`
13. `migrations/013_org_message_menu_permissions.sql`
14. `migrations/014_site_details.sql`
15. `migrations/015_site_details_remove_organization_id_and_truncate.sql`
16. `migrations/016_product_features.sql`
17. `migrations/017_contact_us.sql`
18. `migrations/018_organization_access_restrictions.sql`

## Method 1: Run One-by-One (Recommended)

From project root:

```powershell
$env:PGPASSWORD="postgres"
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/001_init.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/002_org_members_department_designation.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/003_org_members_location.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/004_activity_log.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/005_global_access.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/006_global_access_allow_user_org_scope.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/007_performance_indexes.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/008_activity_log_query_optimizations.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/009_groups_and_related_tables.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/010_group_members_timeline_perf.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/011_groups_lookup_indexes.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/012_api_hotpath_indexes.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/013_org_message_menu_permissions.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/014_site_details.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/015_site_details_remove_organization_id_and_truncate.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/016_product_features.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/017_contact_us.sql
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/018_organization_access_restrictions.sql
```

## Method 2: Run All in a Loop (PowerShell)

```powershell
$env:PGPASSWORD="postgres"
$files = @(
  "migrations/001_init.sql",
  "migrations/002_org_members_department_designation.sql",
  "migrations/003_org_members_location.sql",
  "migrations/004_activity_log.sql",
  "migrations/005_global_access.sql",
  "migrations/006_global_access_allow_user_org_scope.sql",
  "migrations/007_performance_indexes.sql",
  "migrations/008_activity_log_query_optimizations.sql",
  "migrations/009_groups_and_related_tables.sql",
  "migrations/010_group_members_timeline_perf.sql",
  "migrations/011_groups_lookup_indexes.sql",
  "migrations/012_api_hotpath_indexes.sql",
  "migrations/013_org_message_menu_permissions.sql",
  "migrations/014_site_details.sql",
  "migrations/015_site_details_remove_organization_id_and_truncate.sql",
  "migrations/016_product_features.sql",
  "migrations/017_contact_us.sql",
  "migrations/018_organization_access_restrictions.sql"
)

foreach ($f in $files) {
  Write-Host "Running $f ..."
  psql -h localhost -p 5432 -U postgres -d teamChatx -f $f
  if ($LASTEXITCODE -ne 0) {
    throw "Migration failed: $f"
  }
}

Write-Host "All migrations completed."
```

## Verify Migrations

Check key tables:

```sql
\dt
```

Check `global_access`, activity log, and group tables:

```sql
\d global_access
\d activity_log
\d groups
\d group_members
\d group_timeline
\d plan_features
\d site_details
\d site_detail_emails
\d site_detail_phones
\d site_detail_addresses
\d feature_categories
\d feature_items
\d contact_us_requests
```

Check performance indexes:

```sql
SELECT indexname
FROM pg_indexes
WHERE tablename IN (
  'global_access',
  'organization_members',
  'activity_log',
  'otp_verifications',
  'groups',
  'group_members',
  'group_timeline',
  'plan_features',
  'departments',
  'designations',
  'locations',
  'site_details',
  'site_detail_emails',
  'site_detail_phones',
  'site_detail_addresses',
  'feature_categories',
  'feature_items',
  'contact_us_requests'
)
ORDER BY tablename, indexname;
```

`013_org_message_menu_permissions.sql` adds:
- table: `organization_message_menu_permissions`
- index: `idx_menuperm_org_id`
- status column + check:
  - `status VARCHAR(20) NOT NULL DEFAULT 'active'`
  - `CHECK (status IN ('active', 'inactive'))`

`014_site_details.sql` adds:
- table: `site_details` (initially with `organization_id`)
- table: `site_detail_emails` (multiple emails)
- table: `site_detail_phones` (multiple phone numbers)
- table: `site_detail_addresses` (multiple addresses)

`015_site_details_remove_organization_id_and_truncate.sql` changes:
- truncates all records from:
  - `site_details`
  - `site_detail_emails`
  - `site_detail_phones`
  - `site_detail_addresses`
- removes `organization_id` from `site_details`

`016_product_features.sql` adds:
- table: `feature_categories`
- table: `feature_items`
- seed categories:
  - `messaging`, `group`, `audio_video`, `collaboration`, `productivity`, `filters`, `security`, `admin`, `ai_features`
- seed items in `messaging`:
  - `One-On-One Messaging`
  - `Audio Messaging`
  - `Forkout`

`017_contact_us.sql` adds:
- table: `contact_us_requests`
- fields:
  - `name`, `country_code`, `mobile_number`, `email_address`, `company_name`, `total_users`, `requirement_details`
  - workflow status: `new|reviewed|closed`

`018_organization_access_restrictions.sql` adds/updates:
- table: `organization_ip_restrictions`
  - `status` column: `active|inactive`
  - unique rule: `(organization_id, ip_address)`
- table: `organization_platform_restrictions`
  - `restriction_type`: `allow|block`
  - `status` column: `active|inactive`
  - unique rule: `(organization_id, platform_id)`
- safe alter logic for existing DB where table exists but `status` column is missing

Runtime config note:
- contact module admin mail recipient: `.env CONTACT_US_NOTIFY_TO`
- recommended value: `support@teamchatx.com`

`plan_features` module notes:
- current schema is documented in `docs/database.md` under `CREATE TABLE plan_features`.
- if your DB is older and table missing, run the `plan_features` DDL block from `docs/database.md`.

If you only want to apply `status` change manually:

```sql
ALTER TABLE organization_message_menu_permissions
ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'active';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'chk_organization_message_menu_permissions_status'
  ) THEN
    ALTER TABLE organization_message_menu_permissions
    ADD CONSTRAINT chk_organization_message_menu_permissions_status
    CHECK (status IN ('active', 'inactive'));
  END IF;
END $$;
```

## Common Errors

- `relation already exists`
  - means migration already run; check if file uses `IF NOT EXISTS`.
- `permission denied`
  - DB user lacks create/alter privileges.
- `psql: command not found`
  - install PostgreSQL client tools or add `psql` to PATH.
- foreign key errors while applying data manually
  - run migrations first, then seed data in valid order.

## Reset (Dev Only)

If needed, use reset queries from `docs/query.md` and rerun migrations from `001`.

## Update Log (2026-02-25)

- Migration list verified through `017_contact_us.sql`.
- Contact Us runtime env key documented: `CONTACT_US_NOTIFY_TO`.
- Migration list extended with `018_organization_access_restrictions.sql`.
