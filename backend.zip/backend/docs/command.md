# PostgreSQL psql Commands (Cheat Sheet)

Last updated: 2026-02-27

| Command | Purpose (Kaam) | Syntax / Example | Real-World Use Case |
| --- | --- | --- | --- |
| `\l` | Sabhi databases ki list dikhata hai | `\l` | Naya project start karte waqt check karna ki kaun-kaun se DB hain |
| `\l+` | Databases ki list + extra details (size, tablespace, description) | `\l+` | Disk space check karna ya bade databases identify karna |
| `\c <database_name>` | Dusre database mein switch karna (connect) | `\c teamchatx` | Multiple projects ke beech switch karna |
| `\dt` | Current database ke tables ki list | `\dt` | Jaldi se dekhna ki is DB mein kaun-kaun se tables hain |
| `\dt+` | Tables ki list + size, description, access method | `\dt+` | Table sizes check karna (bada table kaun sa hai) |
| `\dt *.*` | Sabhi schemas ke tables dikhata hai | `\dt *.*` | Public + custom schemas ke tables ek saath dekhne ke liye |
| `\d <table_name>` | Table structure (columns, data types, constraints) | `\d users` | Table ka design ya migration check karna |
| `\d+ <table_name>` | Table ki full detail (indexes, constraints, comments, storage, size) | `\d+ messages` | Performance tuning ya debugging (indexes missing?) |
| `\d <schema>.<table>` | Specific schema wali table ki detail | `\d public.roles` | Jab multiple schemas hote hain (staging, prod) |
| `\dn` | Sabhi schemas ki list | `\dn` | Schema structure samajhne ke liye |
| `\du` / `\dg` | Sabhi users aur roles ki list | `\du` | Permissions check karna (admin vs normal user) |
| `\dx` | Installed extensions ki list | `\dx` | PostGIS, pg_trgm, uuid-ossp jaise extensions check karna |
| `\?` | psql ke saare meta-commands ki list | `\?` | Bhool gaye ho to command kya tha? |
| `\h` | SQL command ka syntax help | `\h SELECT` | Syntax ya options jaldi yaad karne ke liye |
| `\h <command>` | Specific SQL keyword ka detailed help | `\h INSERT INTO` | Complex query likhte waqt syntax confirm karna |
| `\q` | psql se bahar nikalna (quit) | `\q` | Kaam khatam hone ke baad |
| `\! <os_command>` | Shell command chalana (psql ke andar se) | `\! ls -l` | Files check karna ya logs dekhna bina psql se bahar nikle |
| `\x` | Output format toggle (normal ? expanded) | `\x` | Bahut saare columns wale records ko readable banane ke liye |
| `\x auto` | Automatically expanded mode on | `\x auto` | Default setting ke liye (recommended) |
| `\timing` | Har query ka execution time dikhana (toggle) | `\timing` | Query performance compare karna |
| `\set <var> <value>` | Custom variable set karna | `\set today '2026-02-11'` | Repeated values (date, ID) ko baar-baar type na karna |
| `\echo :var` | Variable ki value dikhana | `\echo :today` | Variable confirm karne ke liye |
| `\g` | Last query ko dobara chalana | `\g` | Query modify karke turant test karna |
| `\e` | Last query ko editor mein kholna | `\e` | Lambi query edit karne ke liye |
| `\i <filename>` | External SQL file execute karna | `\i migrations/001_create_users.sql` | Migration scripts ya backup files run karna |

## Useful Commands for Site Details Module

```sql
\d site_details
\d site_detail_emails
\d site_detail_phones
\d site_detail_addresses
```

```sql
TRUNCATE TABLE
  site_detail_addresses,
  site_detail_phones,
  site_detail_emails,
  site_details
RESTART IDENTITY;
```

```powershell
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/015_site_details_remove_organization_id_and_truncate.sql
```

## Useful Commands for Product Features Module

```sql
\d feature_categories
\d feature_items
```

```sql
SELECT * FROM feature_categories ORDER BY display_order ASC, feature_category_id ASC;

SELECT
  fi.feature_item_id,
  fc.category_key,
  fc.category_label,
  fi.title,
  fi.description,
  fi.display_order,
  fi.status
FROM feature_items fi
JOIN feature_categories fc ON fc.feature_category_id = fi.feature_category_id
ORDER BY fc.display_order ASC, fi.display_order ASC, fi.feature_item_id ASC;
```

```powershell
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/016_product_features.sql
```

## Useful Commands for Contact Us Module

```sql
\d contact_us_requests
SELECT * FROM contact_us_requests ORDER BY contact_request_id DESC LIMIT 50;
```

```powershell
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/017_contact_us.sql
```

```powershell
# Check notify recipient env (PowerShell session)
echo $env:CONTACT_US_NOTIFY_TO
```

## Useful Commands for Organization Restrictions Module

```sql
\d organization_ip_restrictions
\d organization_platform_restrictions
```

```sql
SELECT * FROM organization_ip_restrictions ORDER BY restriction_id DESC LIMIT 50;
SELECT * FROM organization_platform_restrictions ORDER BY restriction_id DESC LIMIT 50;
```

```powershell
psql -h localhost -p 5432 -U postgres -d teamChatx -f migrations/018_organization_access_restrictions.sql
```

## Update Log (2026-02-25)

- Added module-specific command references for Site Details, Product Features, and Contact Us.
- Included env check command for `CONTACT_US_NOTIFY_TO`.
- Added migration and table-inspection commands for organization restrictions.
