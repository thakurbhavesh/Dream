const locationModel = require('../models/locationModel');
const { success } = require('../utils/response');
const { parsePagination, parseSearch } = require('../utils/common/common_function');
const { withEntityCache, bumpEntityVersion } = require('../utils/cache');
const { buildRequestMeta, buildActorFromRequest, logActivitySafe } = require('../utils/activityLog');

const ENTITY = 'locations';

const createLocation = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: req.body?.organization_id });
    const location = await locationModel.createLocation(req.body);
    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: location.organization_id || actor.context_organization_id,
      target_type: 'location',
      target_id: location.location_id,
      action: 'location.create',
      action_category: 'organization_structure',
      action_subtype: 'location_create',
      description: `Location ${location.label} created`,
      new_values: location,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);
    return success(res, location, 'Location created', 201);
  } catch (error) {
    return next(error);
  }
};

const getLocations = async (req, res, next) => {
  try {
    const data = await withEntityCache(ENTITY, req, async () => {
      const { limit, offset } = parsePagination(req.query);
      const search = parseSearch(req.query);
      const { rows, total } = await locationModel.findAll({
        organization_id: req.query.organization_id,
        search,
        limit,
        offset,
      });
      return { count: total, rows };
    });

    return success(res, data, 'Locations retrieved');
  } catch (error) {
    return next(error);
  }
};

const getLocation = async (req, res, next) => {
  try {
    const location = await withEntityCache(ENTITY, req, async () => {
      const found = await locationModel.findById(req.params.id);
      if (!found) {
        const err = new Error('Location not found');
        err.status = 404;
        throw err;
      }
      return found;
    });

    return success(res, location, 'Location retrieved');
  } catch (error) {
    return next(error);
  }
};

const updateLocation = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req);
    const oldLocation = await locationModel.findById(req.params.id);
    const location = await locationModel.updateLocationPartial(req.params.id, req.body);
    if (!location) {
      const err = new Error('Location not found or no fields to update');
      err.status = 404;
      throw err;
    }
    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: location.organization_id || actor.context_organization_id,
      target_type: 'location',
      target_id: location.location_id,
      action: 'location.update',
      action_category: 'organization_structure',
      action_subtype: 'location_update',
      description: `Location ${location.label} updated`,
      old_values: oldLocation,
      new_values: location,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);
    return success(res, location, 'Location updated');
  } catch (error) {
    return next(error);
  }
};

const patchLocation = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req);
    const oldLocation = await locationModel.findById(req.params.id);
    const location = await locationModel.updateLocationPartial(req.params.id, req.body);
    if (!location) {
      const err = new Error('Location not found or no fields to update');
      err.status = 404;
      throw err;
    }
    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: location.organization_id || actor.context_organization_id,
      target_type: 'location',
      target_id: location.location_id,
      action: 'location.patch',
      action_category: 'organization_structure',
      action_subtype: 'location_patch',
      description: `Location ${location.label} patched`,
      old_values: oldLocation,
      new_values: location,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);
    return success(res, location, 'Location updated');
  } catch (error) {
    return next(error);
  }
};

const deleteLocation = async (req, res, next) => {
  try {
    const deleted = await locationModel.deleteLocation(req.params.id);
    if (!deleted) {
      const err = new Error('Location not found');
      err.status = 404;
      throw err;
    }
    bumpEntityVersion(ENTITY);
    return success(res, null, 'Location deleted');
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  createLocation,
  getLocations,
  getLocation,
  updateLocation,
  patchLocation,
  deleteLocation,
};
