const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const orgUserModel = require('../models/orgUserModel');
const db = require('../config/database');
const { success } = require('../utils/response');
const { parsePagination, parseSearch } = require('../utils/common/common_function');
const { sendMailAsync } = require('../utils/mail');
const {
  getOrgUserAccountCreatedMailTemplate,
  getOrgUserPasswordResetMailTemplate,
} = require('../templates/mail');
const { buildRequestMeta, buildActorFromRequest, logActivitySafe } = require('../utils/activityLog');
const { withEntityCache, bumpEntityVersion } = require('../utils/cache');

const ENTITY = 'org_users';

const resolveOrganizationId = async (req) => {
  const tokenOrgId = Number(req.user?.org);
  const requestedOrgId = Number(req.body?.organization_id || req.query?.organization_id);
  const orgId = Number.isFinite(requestedOrgId) && requestedOrgId > 0 ? requestedOrgId : tokenOrgId;

  if (!Number.isFinite(orgId) || orgId <= 0) {
    const err = new Error('Valid organization context is required');
    err.status = 400;
    throw err;
  }

  const requesterUserId = Number(req.user?.sub);
  if (!Number.isFinite(requesterUserId) || requesterUserId <= 0) {
    const err = new Error('Unauthorized');
    err.status = 401;
    throw err;
  }

  const membershipResult = await db.query(
    `SELECT membership_id
     FROM organization_members
     WHERE organization_id = $1
       AND user_id = $2
       AND status = 'active'
     LIMIT 1`,
    [orgId, requesterUserId]
  );

  if (!membershipResult.rows.length) {
    const err = new Error('Access denied for requested organization');
    err.status = 403;
    throw err;
  }

  return orgId;
};

const createUser = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const user = await orgUserModel.createUserInOrganization({
      organization_id,
      name: req.body.name,
      email: req.body.email,
      mobile: req.body.mobile,
      role_id: req.body.role_id,
      department_id: req.body.department_id,
      designation_id: req.body.designation_id,
      location_id: req.body.location_id,
      is_platform_admin: req.body.is_platform_admin,
      is_global_member: req.body.is_global_member,
    });

    let credential_sent = false;
    if (user.temp_password) {
      const template = getOrgUserAccountCreatedMailTemplate({
        name: user.name,
        tempPassword: user.temp_password,
      });
      sendMailAsync({
        to: user.email,
        subject: template.subject,
        text: template.text,
        html: template.html,
      });
      credential_sent = true;
    }

    const responseData = { ...user, credential_sent };
    delete responseData.temp_password;

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'user',
      target_id: responseData.user_id,
      action: 'user.create',
      action_category: 'user_management',
      action_subtype: 'organization_user_create',
      description: `User ${responseData.email} added to organization ${organization_id}`,
      new_values: responseData,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(res, responseData, 'User created in organization', 201);
  } catch (error) {
    return next(error);
  }
};

const getUsers = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const data = await withEntityCache(ENTITY, req, async () => {
      const all = ['1', 'true', 'yes'].includes(String(req.query?.all || '').toLowerCase());
      const { limit, offset } = all
        ? { limit: 100000, offset: 0 }
        : parsePagination(req.query);
      const search = parseSearch(req.query);
      const { rows, total } = await orgUserModel.findUsersInOrganization({
        organization_id,
        search,
        limit,
        offset,
      });

      return { count: total, rows };
    });

    return success(res, data, 'Organization users retrieved');
  } catch (error) {
    return next(error);
  }
};

const getUser = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const user = await withEntityCache(ENTITY, req, async () =>
      orgUserModel.findUserByIdInOrganization(organization_id, req.params.id)
    );
    if (!user) {
      const err = new Error('User not found in organization');
      err.status = 404;
      throw err;
    }

    return success(res, user, 'Organization user retrieved');
  } catch (error) {
    return next(error);
  }
};

const updateUser = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const oldUser = await orgUserModel.findUserByIdInOrganization(organization_id, req.params.id);
    const user = await orgUserModel.updateUserInOrganization(organization_id, req.params.id, req.body);
    if (!user) {
      const err = new Error('User not found in organization');
      err.status = 404;
      throw err;
    }

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'user',
      target_id: user.user_id,
      action: 'user.update',
      action_category: 'user_management',
      action_subtype: 'organization_user_update',
      description: `User ${user.email} updated in organization ${organization_id}`,
      old_values: oldUser,
      new_values: user,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(res, user, 'Organization user updated');
  } catch (error) {
    return next(error);
  }
};

const bulkUpdateUsers = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const updates = req.body?.updates || [];
    const rows = await orgUserModel.bulkUpdateUsersInOrganization(organization_id, updates);

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'organization_members',
      target_id: organization_id,
      action: 'user.bulk_update',
      action_category: 'user_management',
      action_subtype: 'organization_user_bulk_update',
      description: `${rows.length} users updated in organization ${organization_id}`,
      new_values: {
        count: rows.length,
        user_ids: rows.map((item) => item.user_id),
      },
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(
      res,
      {
        count: rows.length,
        rows,
      },
      'Organization users updated'
    );
  } catch (error) {
    return next(error);
  }
};

const deleteUser = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const oldUser = await orgUserModel.findUserByIdInOrganization(organization_id, req.params.id);
    const user = await orgUserModel.softDeleteUserInOrganization(organization_id, req.params.id);
    if (!user) {
      const err = new Error('User not found in organization');
      err.status = 404;
      throw err;
    }

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'user',
      target_id: user.user_id,
      action: 'user.soft_delete',
      action_category: 'user_management',
      action_subtype: 'membership_left',
      description: `User ${user.email} set to left in organization ${organization_id}`,
      old_values: oldUser,
      new_values: user,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(res, user, 'Organization user status updated');
  } catch (error) {
    return next(error);
  }
};

const resetUserPassword = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const email = String(req.body?.email || '').trim().toLowerCase();
    if (!email) {
      const err = new Error('email is required');
      err.status = 400;
      throw err;
    }

    const providedPassword = req.body?.new_password ? String(req.body.new_password) : null;
    if (providedPassword && providedPassword.length < 8) {
      const err = new Error('new_password must be at least 8 characters');
      err.status = 400;
      throw err;
    }

    if (providedPassword) {
      const existingUserResult = await db.query(
        `SELECT u.password_hash
         FROM organization_members om
         JOIN users u ON u.user_id = om.user_id
         WHERE om.organization_id = $1
           AND LOWER(u.email) = LOWER($2)
         LIMIT 1`,
        [organization_id, email]
      );

      if (existingUserResult.rows.length) {
        const isSamePassword = await bcrypt.compare(providedPassword, existingUserResult.rows[0].password_hash);
        if (isSamePassword) {
          const err = new Error('New password must be different from current password');
          err.status = 400;
          throw err;
        }
      }
    }

    const tempPassword = providedPassword || crypto.randomBytes(6).toString('base64url');
    const passwordHash = await bcrypt.hash(tempPassword, 10);

    const user = await orgUserModel.resetUserPasswordByEmailInOrganization(
      organization_id,
      email,
      passwordHash
    );
    if (!user) {
      const err = new Error('User not found in organization');
      err.status = 404;
      throw err;
    }

    const template = getOrgUserPasswordResetMailTemplate({
      name: user.name,
      tempPassword,
    });

    sendMailAsync({
      to: user.email,
      subject: template.subject,
      text: template.text,
      html: template.html,
    });

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'user',
      target_id: user.user_id,
      action: 'user.password_reset',
      action_category: 'security',
      action_subtype: 'organization_admin_reset',
      description: `Password reset triggered for ${user.email} in organization ${organization_id}`,
      new_values: {
        email: user.email,
        credential_sent: true,
      },
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(
      res,
      {
        email: user.email,
        credential_sent: true,
      },
      'User password reset successfully'
    );
  } catch (error) {
    return next(error);
  }
};

const deactivateUser = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const oldUser = await orgUserModel.findUserByIdInOrganization(organization_id, req.params.id);
    const user = await orgUserModel.deactivateUserInOrganization(organization_id, req.params.id);
    if (!user) {
      const err = new Error('User not found in organization');
      err.status = 404;
      throw err;
    }

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'user',
      target_id: user.user_id,
      action: 'user.deactivate',
      action_category: 'user_management',
      action_subtype: 'status_suspend',
      description: `User ${user.email} deactivated in organization ${organization_id}`,
      old_values: oldUser,
      new_values: user,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(res, user, 'User deactivated successfully');
  } catch (error) {
    return next(error);
  }
};

const activateUser = async (req, res, next) => {
  try {
    const organization_id = await resolveOrganizationId(req);
    const requestMeta = buildRequestMeta(req);
    const actor = buildActorFromRequest(req, { context_organization_id: organization_id });
    const oldUser = await orgUserModel.findUserByIdInOrganization(organization_id, req.params.id);
    const user = await orgUserModel.activateUserInOrganization(organization_id, req.params.id);
    if (!user) {
      const err = new Error('User not found in organization');
      err.status = 404;
      throw err;
    }

    await logActivitySafe({
      ...actor,
      ...requestMeta,
      context_organization_id: organization_id,
      target_type: 'user',
      target_id: user.user_id,
      action: 'user.activate',
      action_category: 'user_management',
      action_subtype: 'status_active',
      description: `User ${user.email} activated in organization ${organization_id}`,
      old_values: oldUser,
      new_values: user,
      is_successful: true,
      status: 'success',
    });
    bumpEntityVersion(ENTITY);

    return success(res, user, 'User activated successfully');
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  createUser,
  getUsers,
  getUser,
  updateUser,
  bulkUpdateUsers,
  deleteUser,
  resetUserPassword,
  deactivateUser,
  activateUser,
};
