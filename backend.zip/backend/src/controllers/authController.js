const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const db = require('../config/database');
const userModel = require('../models/userModel');
const sessionModel = require('../models/sessionModel');
const userDeviceModel = require('../models/userDeviceModel');
const { sendMailAsync } = require('../utils/mail');
const {
  getVerificationOtpMailTemplate,
  getForgotPasswordOtpMailTemplate,
  getPasswordResetSuccessMailTemplate,
} = require('../templates/mail');
const { success } = require('../utils/response');
const { buildRequestMeta, buildActorFromRequest, logActivitySafe } = require('../utils/activityLog');
const {
  signAccessToken,
  generateRefreshToken,
  hashToken,
  getRefreshExpiryDate,
} = require('../utils/jwt');

const ALLOWED_DEVICE_TYPES = new Set(['mobile', 'desktop', 'tablet', 'other']);
const FREE_EMAIL_DOMAINS = new Set([
  '163.com',
  '126.com',
  'gmail.com',
  'yahoo.com',
  'ymail.com',
  'rocketmail.com',
  'outlook.com',
  'outlook.in',
  'outlook.co.in',
  'outlook.co.uk',
  'hotmail.com',
  'hotmail.co.uk',
  'hotmail.fr',
  'hotmail.de',
  'live.com',
  'live.in',
  'aol.com',
  'icloud.com',
  'me.com',
  'mac.com',
  'proton.me',
  'protonmail.com',
  'pm.me',
  'protonmail.ch',
  'tutanota.com',
  'tuta.io',
  'fastmail.com',
  'gmx.com',
  'gmx.de',
  'gmx.net',
  'mail.com',
  'inbox.com',
  'yandex.com',
  'yandex.ru',
  'yandex.com.tr',
  'zoho.com',
  'zoho.in',
  'zohomail.com',
  'rediffmail.com',
  'indiatimes.com',
  'sify.com',
  'lycos.com',
  'hushmail.com',
  'qq.com',
  'naver.com',
  'daum.net',
  'hanmail.net',
  'seznam.cz',
  'web.de',
  'mail.ru',
  'bk.ru',
  'list.ru',
  'inbox.ru',
]);

const normalizeEmail = (value) => String(value || '').trim().toLowerCase();
const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(email));
const getEmailDomain = (email) => normalizeEmail(email).split('@')[1] || null;

const ensureBusinessEmail = (email) => {
  const normalized = normalizeEmail(email);
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(normalized)) {
    const err = new Error('Valid email is required');
    err.status = 400;
    throw err;
  }

  const domain = normalized.split('@')[1];
  if (!domain || FREE_EMAIL_DOMAINS.has(domain)) {
    const err = new Error('Only business email is allowed');
    err.status = 400;
    throw err;
  }

  return normalized;
};

const normalizePhone = (value) => {
  const cleaned = String(value || '').trim().replace(/[\s\-()]/g, '');
  if (!/^\+?[1-9]\d{7,14}$/.test(cleaned)) {
    const err = new Error('Valid phone is required (8-15 digits, optional +)');
    err.status = 400;
    throw err;
  }
  return cleaned;
};

const slugify = (value) =>
  String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80);

const generateOtpCode = () => {
  return String(crypto.randomInt(0, 1000000)).padStart(6, '0');
};

const sendVerificationOtpEmail = async ({ to, ownerName, otpCode, otpExpiresMinutes = 10 }) => {
  const template = getVerificationOtpMailTemplate({
    ownerName,
    otpCode,
    otpExpiresMinutes,
  });
  sendMailAsync({
    to,
    subject: template.subject,
    text: template.text,
    html: template.html,
  });
};

const sendForgotPasswordOtpEmail = async ({ to, ownerName, otpCode, otpExpiresMinutes = 10 }) => {
  const template = getForgotPasswordOtpMailTemplate({
    ownerName,
    otpCode,
    otpExpiresMinutes,
  });
  sendMailAsync({
    to,
    subject: template.subject,
    text: template.text,
    html: template.html,
  });
};

const sendPasswordResetSuccessEmail = async ({ to, ownerName }) => {
  const template = getPasswordResetSuccessMailTemplate({
    ownerName,
    supportEmail: process.env.SECURITY_SUPPORT_EMAIL || process.env.SMTP_FROM || 'support@teamchatx.com',
  });
  sendMailAsync({
    to,
    subject: template.subject,
    text: template.text,
    html: template.html,
  });
};

const signPasswordResetToken = ({ user_id, organization_id, email, otp_id }) => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    const err = new Error('JWT_SECRET is not set');
    err.status = 500;
    throw err;
  }

  return jwt.sign(
    {
      sub: Number(user_id),
      org: organization_id ? Number(organization_id) : null,
      email: normalizeEmail(email),
      otp_id: Number(otp_id),
      purpose: 'password_reset',
    },
    secret,
    { expiresIn: process.env.RESET_PASSWORD_TOKEN_EXPIRES_IN || '15m' }
  );
};

const verifyPasswordResetToken = (token) => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    const err = new Error('JWT_SECRET is not set');
    err.status = 500;
    throw err;
  }
  return jwt.verify(token, secret);
};

const buildResetPasswordLink = ({ resetToken, email }) => {
  const base =
    process.env.RESET_PASSWORD_LINK_BASE ||
    `${String(process.env.FRONTEND_URL || '').replace(/\/+$/, '')}/auth/reset-password`;
  if (!base || base === '/auth/reset-password') return null;

  const separator = base.includes('?') ? '&' : '?';
  return `${base}${separator}token=${encodeURIComponent(resetToken)}&email=${encodeURIComponent(email)}`;
};

const generateOrgKey = (base) => {
  const safe = (base || 'org').replace(/[^a-z0-9]/gi, '').toLowerCase().slice(0, 40) || 'org';
  const suffix = crypto.randomBytes(4).toString('hex');
  return `${safe}_${suffix}`;
};

const getDevicePayload = (req = {}) => {
  const body = req.body || {};
  const ipAddress = req.ip || req.socket?.remoteAddress || '0.0.0.0';
  const rawDeviceType = (body.device_type || body.deviceType || 'other').toString().trim().toLowerCase();
  if (!ALLOWED_DEVICE_TYPES.has(rawDeviceType)) {
    const err = new Error('device_type must be one of mobile, desktop, tablet, other');
    err.status = 400;
    throw err;
  }

  const rawDeviceName = (body.device_name || body.deviceName || '').toString().trim();

  return {
    device_name: rawDeviceName ? rawDeviceName.slice(0, 120) : 'Unknown Device',
    device_type: rawDeviceType,
    latitude: body.latitude ?? null,
    longitude: body.longitude ?? null,
    accuracy_radius: body.accuracy_radius ?? body.accuracyRadius ?? null,
    country: body.country || null,
    city: body.city || null,
    ip_address: ipAddress,
    user_agent: req.headers?.['user-agent'] || null,
  };
};

const register = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const { email, name, password } = req.body;
    if (!email || !name || !password) {
      const err = new Error('email, name, and password are required');
      err.status = 400;
      throw err;
    }

    const existing = await userModel.findByEmailWithMembership(email);
    if (existing) {
      const err = new Error('Email already exists');
      err.status = 409;
      throw err;
    }

    const password_hash = await bcrypt.hash(password, 10);
    const user = await userModel.createUser({ email, name, password_hash });
    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: user.user_id,
        actor_role_key: 'self',
      }),
      ...requestMeta,
      target_type: 'user',
      target_id: user.user_id,
      action: 'auth.register',
      action_category: 'auth',
      action_subtype: 'register',
      description: `User registered with email ${user.email}`,
      new_values: {
        user_id: user.user_id,
        email: user.email,
        name: user.name,
      },
      is_successful: true,
      status: 'success',
    });
    return success(res, { user_id: user.user_id, email: user.email, name: user.name }, 'User registered', 201);
  } catch (error) {
    return next(error);
  }
};

const createNewAccount = async (req, res, next) => {
  try {
    const { company_name, owner_name, email, phone, password } = req.body || {};

    if (!company_name || !owner_name || !email || !phone || !password) {
      const err = new Error('company_name, owner_name, email, phone, password are required');
      err.status = 400;
      throw err;
    }

    if (String(company_name).trim().length < 2 || String(company_name).trim().length > 150) {
      const err = new Error('company_name must be between 2 and 150 characters');
      err.status = 400;
      throw err;
    }

    if (String(owner_name).trim().length < 2 || String(owner_name).trim().length > 120) {
      const err = new Error('owner_name must be between 2 and 120 characters');
      err.status = 400;
      throw err;
    }

    if (String(password).length < 8) {
      const err = new Error('password must be at least 8 characters');
      err.status = 400;
      throw err;
    }

    const normalizedEmail = ensureBusinessEmail(email);
    const emailDomain = getEmailDomain(normalizedEmail);
    if (!emailDomain) {
      const err = new Error('Unable to derive domain from email');
      err.status = 400;
      throw err;
    }

    const normalizedPhone = normalizePhone(phone);
    const orgName = String(company_name).trim();
    const ownerName = String(owner_name).trim();
    const password_hash = await bcrypt.hash(String(password), 10);
    const otpCode = generateOtpCode();

    const account = await db.withTransaction(async (tx) => {
      const existingUser = await tx.query(
        'SELECT user_id FROM users WHERE LOWER(email) = LOWER($1) LIMIT 1',
        [normalizedEmail]
      );

      if (existingUser.rows.length) {
        const err = new Error('Email already exists');
        err.status = 409;
        throw err;
      }

      const existingOrgByDomain = await tx.query(
        `SELECT organization_id
         FROM organizations
         WHERE LOWER(custom_domain) = LOWER($1)
         LIMIT 1`,
        [emailDomain]
      );

      if (existingOrgByDomain.rows.length) {
        const err = new Error('Organization already exist');
        err.status = 409;
        throw err;
      }

      const roleCheck = await tx.query('SELECT role_id FROM roles WHERE role_id = 3 LIMIT 1');
      if (!roleCheck.rows.length) {
        const err = new Error('Default role_id 3 is missing in roles table');
        err.status = 500;
        throw err;
      }

      const planResult = await tx.query(
        'SELECT plan_id, interval_days, max_users, max_storage_mb FROM plans WHERE plan_id = 1 LIMIT 1'
      );
      if (!planResult.rows.length) {
        const err = new Error('Default plan_id 1 is missing in plans table');
        err.status = 500;
        throw err;
      }
      const defaultPlan = planResult.rows[0];
      const intervalDays = Number(defaultPlan.interval_days);
      if (!Number.isFinite(intervalDays) || intervalDays <= 0) {
        const err = new Error('Default plan interval_days must be greater than 0');
        err.status = 500;
        throw err;
      }

      const userResult = await tx.query(
        `INSERT INTO users (email, name, password_hash, mobile, is_platform_admin, is_global_member)
         VALUES ($1, $2, $3, $4, FALSE, FALSE)
         RETURNING user_id, email, name, mobile`,
        [normalizedEmail, ownerName, password_hash, normalizedPhone]
      );
      const user = userResult.rows[0];

      const baseSubdomain = slugify(orgName) || 'org';
      let subdomain = baseSubdomain;
      let orgKey = generateOrgKey(baseSubdomain);

      for (let attempt = 0; attempt < 5; attempt += 1) {
        const subdomainCheck = await tx.query(
          'SELECT organization_id FROM organizations WHERE subdomain = $1 LIMIT 1',
          [subdomain]
        );
        const orgKeyCheck = await tx.query(
          'SELECT organization_id FROM organizations WHERE org_key = $1 LIMIT 1',
          [orgKey]
        );

        if (!subdomainCheck.rows.length && !orgKeyCheck.rows.length) {
          break;
        }

        const suffix = crypto.randomBytes(2).toString('hex');
        subdomain = `${baseSubdomain}-${suffix}`.slice(0, 100);
        orgKey = generateOrgKey(`${baseSubdomain}${suffix}`);
      }

      const organizationResult = await tx.query(
        `INSERT INTO organizations (
           org_key, name, subdomain, custom_domain, owner_id, language_id, timezone_id, storage_used_mb, status
         )
         VALUES ($1, $2, $3, $4, $5, 1, 1, 0, 'active')
         RETURNING organization_id, org_key, name, subdomain, custom_domain, storage_used_mb, status`,
        [orgKey, orgName, subdomain, emailDomain, user.user_id]
      );
      const organization = organizationResult.rows[0];

      await tx.query(
        `INSERT INTO organization_members (organization_id, user_id, role_id, status)
         VALUES ($1, $2, 3, 'active')`,
        [organization.organization_id, user.user_id]
      );

      await tx.query(
        `INSERT INTO subscriptions (
           organization_id, plan_id, status, start_date, end_date, max_users, max_storage_mb
         )
         VALUES ($1, $2, 'active', CURRENT_DATE, CURRENT_DATE + ($5 * INTERVAL '1 day'), $3, $4)`,
        [
          organization.organization_id,
          defaultPlan.plan_id,
          defaultPlan.max_users,
          defaultPlan.max_storage_mb,
          intervalDays,
        ]
      );

      const otpResult = await tx.query(
        `INSERT INTO otp_verifications (
           user_id, organization_id, identifier, type, otp_code, purpose, status, expires_at, ip_address
         )
         VALUES ($1, $2, $3, 'email', $4, 'verification', 'pending', NOW() + INTERVAL '10 minutes', $5)
         RETURNING otp_id, expires_at`,
        [user.user_id, organization.organization_id, user.email, otpCode, req.ip || null]
      );

      return {
        user,
        organization,
        otp: otpResult.rows[0],
      };
    });

    await sendVerificationOtpEmail({
      to: account.user.email,
      ownerName,
      otpCode,
      otpExpiresMinutes: 10,
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: account.user.user_id,
        actor_role_key: 'owner',
        context_organization_id: account.organization.organization_id,
      }),
      ...buildRequestMeta(req),
      target_type: 'organization',
      target_id: account.organization.organization_id,
      action: 'auth.create_account',
      action_category: 'auth',
      action_subtype: 'organization_onboarding',
      description: `Account created for ${account.user.email}`,
      new_values: {
        user_id: account.user.user_id,
        email: account.user.email,
        organization_id: account.organization.organization_id,
        otp_id: account.otp.otp_id,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        user: account.user,
        organization: account.organization,
        otp: {
          otp_id: account.otp.otp_id,
          expires_at: account.otp.expires_at,
        },
      },
      'Account created. Verification OTP sent to business email.',
      201
    );
  } catch (error) {
    return next(error);
  }
};

const resendOtp = async (req, res, next) => {
  try {
    const { email } = req.body || {};
    if (!email) {
      const err = new Error('email is required');
      err.status = 400;
      throw err;
    }

    const normalizedEmail = normalizeEmail(email);
    if (!isValidEmail(normalizedEmail)) {
      const err = new Error('Valid email is required');
      err.status = 400;
      throw err;
    }

    const payload = await db.withTransaction(async (tx) => {
      const userResult = await tx.query(
        `SELECT user_id, name, email, email_verified_at
         FROM users
         WHERE LOWER(email) = LOWER($1)
         LIMIT 1`,
        [normalizedEmail]
      );

      if (!userResult.rows.length) {
        const err = new Error('Email is not registered');
        err.status = 404;
        throw err;
      }

      const user = userResult.rows[0];
      if (user.email_verified_at) {
        const err = new Error('Email already verified');
        err.status = 409;
        throw err;
      }

      const membershipResult = await tx.query(
        `SELECT om.organization_id
         FROM organization_members om
         WHERE om.user_id = $1
         ORDER BY om.joined_at ASC NULLS LAST
         LIMIT 1`,
        [user.user_id]
      );

      const organizationId = membershipResult.rows[0]?.organization_id || null;

      await tx.query(
        `UPDATE otp_verifications
         SET status = 'expired'
         WHERE LOWER(identifier) = LOWER($1)
           AND type = 'email'
           AND purpose = 'verification'
           AND status = 'pending'`,
        [normalizedEmail]
      );

      const otpCode = generateOtpCode();
      const otpInsertResult = await tx.query(
        `INSERT INTO otp_verifications (
           user_id, organization_id, identifier, type, otp_code, purpose, status, expires_at, ip_address
         )
         VALUES ($1, $2, $3, 'email', $4, 'verification', 'pending', NOW() + INTERVAL '10 minutes', $5)
         RETURNING otp_id, expires_at`,
        [user.user_id, organizationId, user.email, otpCode, req.ip || null]
      );

      return {
        email: user.email,
        owner_name: user.name || 'User',
        otp_code: otpCode,
        otp: otpInsertResult.rows[0],
      };
    });

    await sendVerificationOtpEmail({
      to: payload.email,
      ownerName: payload.owner_name,
      otpCode: payload.otp_code,
      otpExpiresMinutes: 10,
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_role_key: 'self',
      }),
      ...buildRequestMeta(req),
      target_type: 'otp_verification',
      target_id: payload.otp.otp_id,
      action: 'auth.resend_otp',
      action_category: 'security',
      action_subtype: 'verification_otp',
      description: `Verification OTP resent to ${payload.email}`,
      new_values: {
        email: payload.email,
        otp_id: payload.otp.otp_id,
        expires_at: payload.otp.expires_at,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        email: payload.email,
        otp: payload.otp,
      },
      'OTP resent successfully'
    );
  } catch (error) {
    return next(error);
  }
};

const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body || {};
    if (!email) {
      const err = new Error('email is required');
      err.status = 400;
      throw err;
    }

    const normalizedEmail = normalizeEmail(email);
    if (!isValidEmail(normalizedEmail)) {
      const err = new Error('Valid email is required');
      err.status = 400;
      throw err;
    }

    const payload = await db.withTransaction(async (tx) => {
      const userResult = await tx.query(
        `SELECT user_id, name, email
         FROM users
         WHERE LOWER(email) = LOWER($1)
         LIMIT 1`,
        [normalizedEmail]
      );

      if (!userResult.rows.length) {
        const err = new Error('Email is not registered');
        err.status = 404;
        throw err;
      }

      const user = userResult.rows[0];
      const membershipResult = await tx.query(
        `SELECT organization_id
         FROM organization_members
         WHERE user_id = $1
         ORDER BY joined_at ASC NULLS LAST
         LIMIT 1`,
        [user.user_id]
      );

      const organizationId = membershipResult.rows[0]?.organization_id || null;

      await tx.query(
        `UPDATE otp_verifications
         SET status = 'expired'
         WHERE LOWER(identifier) = LOWER($1)
           AND type = 'email'
           AND purpose = 'password_reset'
           AND status = 'pending'`,
        [normalizedEmail]
      );

      const otpCode = generateOtpCode();
      const otpResult = await tx.query(
        `INSERT INTO otp_verifications (
           user_id, organization_id, identifier, type, otp_code, purpose, status, expires_at, ip_address
         )
         VALUES ($1, $2, $3, 'email', $4, 'password_reset', 'pending', NOW() + INTERVAL '10 minutes', $5)
         RETURNING otp_id, expires_at`,
        [user.user_id, organizationId, user.email, otpCode, req.ip || null]
      );

      return {
        email: user.email,
        owner_name: user.name || 'User',
        otp_code: otpCode,
        otp: otpResult.rows[0],
      };
    });

    await sendForgotPasswordOtpEmail({
      to: payload.email,
      ownerName: payload.owner_name,
      otpCode: payload.otp_code,
      otpExpiresMinutes: 10,
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_role_key: 'self',
      }),
      ...buildRequestMeta(req),
      target_type: 'otp_verification',
      target_id: payload.otp.otp_id,
      action: 'auth.forgot_password_otp',
      action_category: 'security',
      action_subtype: 'password_reset_otp',
      description: `Password reset OTP issued for ${payload.email}`,
      new_values: {
        email: payload.email,
        otp_id: payload.otp.otp_id,
        expires_at: payload.otp.expires_at,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        email: payload.email,
        otp: payload.otp,
      },
      'Password reset OTP sent'
    );
  } catch (error) {
    return next(error);
  }
};

const verifyForgotPasswordOtp = async (req, res, next) => {
  try {
    const { email, otp_code } = req.body || {};
    if (!email || !otp_code) {
      const err = new Error('email and otp_code are required');
      err.status = 400;
      throw err;
    }

    const normalizedEmail = normalizeEmail(email);
    if (!isValidEmail(normalizedEmail)) {
      const err = new Error('Valid email is required');
      err.status = 400;
      throw err;
    }

    const normalizedOtp = String(otp_code).trim();
    if (!/^\d{6}$/.test(normalizedOtp)) {
      const err = new Error('otp_code must be a 6-digit code');
      err.status = 400;
      throw err;
    }

    const resetContext = await db.withTransaction(async (tx) => {
      const userResult = await tx.query(
        `SELECT user_id, email
         FROM users
         WHERE LOWER(email) = LOWER($1)
         LIMIT 1`,
        [normalizedEmail]
      );

      if (!userResult.rows.length) {
        const err = new Error('Email is not registered');
        err.status = 404;
        throw err;
      }

      const user = userResult.rows[0];
      const otpResult = await tx.query(
        `SELECT *
         FROM otp_verifications
         WHERE LOWER(identifier) = LOWER($1)
           AND type = 'email'
           AND purpose = 'password_reset'
         ORDER BY created_at DESC
         LIMIT 1`,
        [normalizedEmail]
      );

      if (!otpResult.rows.length) {
        const err = new Error('No password reset OTP found');
        err.status = 404;
        throw err;
      }

      const otp = otpResult.rows[0];
      if (otp.status === 'verified') {
        const err = new Error('OTP already used');
        err.status = 409;
        throw err;
      }

      if (otp.status === 'failed') {
        return {
          otp_error: {
            message: 'Maximum OTP attempts reached. Contact support for reset password.',
            status: 200,
            details: {
              attempt_number: Number(otp.max_attempts || 5),
              max_attempts: Number(otp.max_attempts || 5),
              attempts_left: 0,
            },
          },
        };
      }

      if (otp.status !== 'pending') {
        const err = new Error(`OTP is ${otp.status}. Please request a new OTP`);
        err.status = 400;
        throw err;
      }

      if (otp.expires_at && new Date(otp.expires_at) <= new Date()) {
        await tx.query(
          `UPDATE otp_verifications
           SET status = 'expired'
           WHERE otp_id = $1`,
          [otp.otp_id]
        );
        const err = new Error('OTP expired');
        err.status = 400;
        throw err;
      }

      const nextAttempt = Number(otp.attempt_count || 0) + 1;
      if (otp.otp_code !== normalizedOtp) {
        const maxAttempts = Number(otp.max_attempts || 5);
        const reachedMax = nextAttempt >= maxAttempts;
        const remainingAttempts = Math.max(maxAttempts - nextAttempt, 0);
        await tx.query(
          `UPDATE otp_verifications
           SET attempt_count = $1,
               status = CASE WHEN $2 THEN 'failed' ELSE status END
           WHERE otp_id = $3`,
          [nextAttempt, reachedMax, otp.otp_id]
        );
        return {
          otp_error: {
            message: reachedMax
              ? 'Maximum OTP attempts reached. Contact support for reset password.'
              : `Invalid OTP. Attempt ${nextAttempt}/${maxAttempts}. ${remainingAttempts} attempts left`,
            status: 200,
            details: {
              attempt_number: nextAttempt,
              max_attempts: maxAttempts,
              attempts_left: remainingAttempts,
            },
          },
        };
      }

      await tx.query(
        `UPDATE otp_verifications
         SET status = 'verified',
             verified_at = NOW()
         WHERE otp_id = $1`,
        [otp.otp_id]
      );

      return {
        user_id: user.user_id,
        email: user.email,
        otp_id: otp.otp_id,
        organization_id: otp.organization_id || null,
      };
    });

    if (resetContext?.otp_error) {
      const err = new Error(resetContext.otp_error.message);
      err.status = resetContext.otp_error.status;
      err.details = resetContext.otp_error.details;
      throw err;
    }

    const reset_token = signPasswordResetToken({
      user_id: resetContext.user_id,
      organization_id: resetContext.organization_id,
      email: resetContext.email,
      otp_id: resetContext.otp_id,
    });
    const reset_link = buildResetPasswordLink({
      resetToken: reset_token,
      email: resetContext.email,
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: resetContext.user_id,
        actor_role_key: 'self',
        context_organization_id: resetContext.organization_id,
      }),
      ...buildRequestMeta(req),
      target_type: 'otp_verification',
      target_id: resetContext.otp_id,
      action: 'auth.forgot_verify',
      action_category: 'security',
      action_subtype: 'password_reset_otp_verified',
      description: `Password reset OTP verified for ${normalizedEmail}`,
      new_values: {
        email: normalizedEmail,
        otp_id: resetContext.otp_id,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        email: normalizedEmail,
        reset_token,
        reset_link,
      },
      'OTP verified. Use reset_token to set a new password.'
    );
  } catch (error) {
    return next(error);
  }
};

const resetPassword = async (req, res, next) => {
  try {
    const { reset_token, new_password } = req.body || {};
    if (!reset_token || !new_password) {
      const err = new Error('reset_token and new_password are required');
      err.status = 400;
      throw err;
    }

    if (String(new_password).length < 8) {
      const err = new Error('new_password must be at least 8 characters');
      err.status = 400;
      throw err;
    }

    let tokenPayload;
    try {
      tokenPayload = verifyPasswordResetToken(String(reset_token));
    } catch (tokenError) {
      const err = new Error('Invalid or expired reset_token');
      err.status = 401;
      throw err;
    }

    if (tokenPayload?.purpose !== 'password_reset') {
      const err = new Error('Invalid reset_token purpose');
      err.status = 401;
      throw err;
    }

    const tokenUserId = Number(tokenPayload?.sub);
    const tokenOtpId = Number(tokenPayload?.otp_id);
    const tokenEmail = normalizeEmail(tokenPayload?.email || '');

    if (!Number.isFinite(tokenUserId) || tokenUserId <= 0 || !Number.isFinite(tokenOtpId) || tokenOtpId <= 0) {
      const err = new Error('Invalid reset_token payload');
      err.status = 401;
      throw err;
    }

    const resetContext = await db.withTransaction(async (tx) => {
      const userResult = await tx.query(
        `SELECT user_id, email, name, password_hash
         FROM users
         WHERE user_id = $1
         LIMIT 1`,
        [tokenUserId]
      );

      if (!userResult.rows.length) {
        const err = new Error('User not found');
        err.status = 404;
        throw err;
      }

      const user = userResult.rows[0];
      if (tokenEmail && normalizeEmail(user.email) !== tokenEmail) {
        const err = new Error('reset_token does not match user');
        err.status = 401;
        throw err;
      }

      const otpResult = await tx.query(
        `SELECT otp_id, status, purpose, user_id, organization_id
         FROM otp_verifications
         WHERE otp_id = $1
         LIMIT 1`,
        [tokenOtpId]
      );

      if (!otpResult.rows.length) {
        const err = new Error('Invalid reset_token reference');
        err.status = 401;
        throw err;
      }

      const otp = otpResult.rows[0];
      if (Number(otp.user_id) !== Number(user.user_id)) {
        const err = new Error('reset_token OTP/user mismatch');
        err.status = 401;
        throw err;
      }

      if (otp.purpose !== 'password_reset') {
        const err = new Error('Invalid OTP purpose for password reset');
        err.status = 401;
        throw err;
      }

      if (otp.status !== 'verified') {
        const err = new Error('Reset token is no longer valid. Verify OTP again.');
        err.status = 401;
        throw err;
      }

      const isSamePassword = await bcrypt.compare(String(new_password), user.password_hash);
      if (isSamePassword) {
        const err = new Error('New password must be different from current password');
        err.status = 400;
        throw err;
      }

      const passwordHash = await bcrypt.hash(String(new_password), 10);
      await tx.query(
        `UPDATE users
         SET password_hash = $1,
             updated_at = NOW()
         WHERE user_id = $2`,
        [passwordHash, user.user_id]
      );

      await tx.query(
        `UPDATE user_sessions
         SET status = 'revoked',
             revoked_at = NOW()
         WHERE user_id = $1
           AND status = 'active'`,
        [user.user_id]
      );

      await tx.query(
        `UPDATE otp_verifications
         SET status = 'expired'
         WHERE otp_id = $1`,
        [otp.otp_id]
      );

      return {
        user_id: user.user_id,
        email: user.email,
        name: user.name || 'User',
        organization_id: otp.organization_id || null,
      };
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: resetContext.user_id,
        actor_role_key: 'self',
        context_organization_id: resetContext.organization_id,
      }),
      ...buildRequestMeta(req),
      target_type: 'user',
      target_id: resetContext.user_id,
      action: 'auth.reset_password',
      action_category: 'security',
      action_subtype: 'password_reset',
      description: `Password reset successful for ${normalizeEmail(resetContext.email)}`,
      new_values: {
        email: normalizeEmail(resetContext.email),
      },
      is_successful: true,
      status: 'success',
    });

    await sendPasswordResetSuccessEmail({
      to: resetContext.email,
      ownerName: resetContext.name,
    });

    return success(res, { email: normalizeEmail(resetContext.email) }, 'Password reset successful');
  } catch (error) {
    return next(error);
  }
};

const verifyOtp = async (req, res, next) => {
  try {
    const { email, otp_code } = req.body || {};
    if (!email || !otp_code) {
      const err = new Error('email and otp_code are required');
      err.status = 400;
      throw err;
    }

    const normalizedEmail = normalizeEmail(email);
    if (!isValidEmail(normalizedEmail)) {
      const err = new Error('Valid email is required');
      err.status = 400;
      throw err;
    }

    const normalizedOtp = String(otp_code).trim();
    if (!/^\d{6}$/.test(normalizedOtp)) {
      const err = new Error('otp_code must be a 6-digit code');
      err.status = 400;
      throw err;
    }

    const result = await db.withTransaction(async (tx) => {
      const userResult = await tx.query(
        `SELECT user_id, email_verified_at
         FROM users
         WHERE LOWER(email) = LOWER($1)
         LIMIT 1`,
        [normalizedEmail]
      );

      if (!userResult.rows.length) {
        const err = new Error('Email is not registered');
        err.status = 404;
        throw err;
      }

      const user = userResult.rows[0];
      if (user.email_verified_at) {
        const err = new Error('Email already verified');
        err.status = 409;
        throw err;
      }

      const otpResult = await tx.query(
        `SELECT *
         FROM otp_verifications
         WHERE LOWER(identifier) = LOWER($1)
           AND type = 'email'
           AND purpose = 'verification'
         ORDER BY created_at DESC
         LIMIT 1`,
        [normalizedEmail]
      );

      if (!otpResult.rows.length) {
        const err = new Error('No OTP generated for this email');
        err.status = 404;
        throw err;
      }

      const otp = otpResult.rows[0];
      if (otp.status === 'verified') {
        const err = new Error('OTP already used');
        err.status = 409;
        throw err;
      }

      if (otp.status === 'failed') {
        const err = new Error('OTP blocked due to max attempts. Please request a new OTP');
        err.status = 429;
        throw err;
      }

      if (otp.status !== 'pending') {
        const err = new Error(`OTP is ${otp.status}. Please request a new OTP`);
        err.status = 400;
        throw err;
      }

      if (otp.expires_at && new Date(otp.expires_at) <= new Date()) {
        await tx.query(
          `UPDATE otp_verifications
           SET status = 'expired'
           WHERE otp_id = $1`,
          [otp.otp_id]
        );
        const err = new Error('OTP expired');
        err.status = 400;
        throw err;
      }

      const nextAttempt = Number(otp.attempt_count || 0) + 1;
      if (otp.otp_code !== normalizedOtp) {
        const reachedMax = nextAttempt >= Number(otp.max_attempts || 5);
        const remainingAttempts = Math.max(Number(otp.max_attempts || 5) - nextAttempt, 0);
        await tx.query(
          `UPDATE otp_verifications
           SET attempt_count = $1,
               status = CASE WHEN $2 THEN 'failed' ELSE status END
           WHERE otp_id = $3`,
          [nextAttempt, reachedMax, otp.otp_id]
        );
        const err = new Error(
          reachedMax
            ? 'OTP failed: max attempts reached. Please request a new OTP'
            : `Invalid OTP. ${remainingAttempts} attempts left`
        );
        err.status = 400;
        throw err;
      }

      await tx.query(
        `UPDATE otp_verifications
         SET status = 'verified',
             verified_at = NOW()
         WHERE otp_id = $1`,
        [otp.otp_id]
      );

      await tx.query(
        `UPDATE users
         SET email_verified_at = NOW(),
             updated_at = NOW()
         WHERE user_id = $1`,
        [otp.user_id]
      );

      return {
        user_id: otp.user_id,
        organization_id: otp.organization_id,
        otp_id: otp.otp_id,
      };
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: result.user_id,
        actor_role_key: 'self',
        context_organization_id: result.organization_id,
      }),
      ...buildRequestMeta(req),
      target_type: 'otp_verification',
      target_id: result.otp_id,
      action: 'auth.verify_otp',
      action_category: 'security',
      action_subtype: 'email_verification',
      description: `Email verified for ${normalizedEmail}`,
      new_values: {
        email: normalizedEmail,
        user_id: result.user_id,
        organization_id: result.organization_id,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        verified: true,
        user_id: result.user_id,
        organization_id: result.organization_id,
      },
      'OTP verified successfully'
    );
  } catch (error) {
    return next(error);
  }
};

const login = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const { email, password } = req.body;
    if (!email || !password) {
      const err = new Error('email and password are required');
      err.status = 400;
      throw err;
    }

    const user = await userModel.findByEmailWithMembership(email);
    if (!user) {
      const err = new Error('Invalid credentials');
      err.status = 401;
      throw err;
    }

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      const err = new Error('Invalid credentials');
      err.status = 401;
      throw err;
    }

    const payload = {
      sub: user.user_id,
      email: user.email,
      org: user.organization_id || null,
      role_id: user.role_id || null,
      role: user.role_key || null,
      name: user.name,
    };

    const access_token = signAccessToken(payload);

    const refresh_token = generateRefreshToken();
    const refresh_token_hash = hashToken(refresh_token);
    const expires_at = getRefreshExpiryDate();
    const devicePayload = getDevicePayload(req);
    const device = await userDeviceModel.upsertDeviceForLogin({
      user_id: user.user_id,
      ...devicePayload,
    });

    await sessionModel.createSession({
      user_id: user.user_id,
      organization_id: user.organization_id,
      refresh_token_hash,
      user_agent: devicePayload.user_agent,
      ip_address: devicePayload.ip_address,
      device_id: device.device_id,
      expires_at,
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: user.user_id,
        actor_role_key: user.role_key || 'self',
        context_organization_id: user.organization_id || null,
      }),
      ...requestMeta,
      context_organization_id: user.organization_id || null,
      target_type: 'user_session',
      target_id: device.device_id || null,
      action: 'auth.login',
      action_category: 'auth',
      action_subtype: 'login',
      description: `Login successful for ${user.email}`,
      new_values: {
        user_id: user.user_id,
        organization_id: user.organization_id || null,
        role_id: user.role_id || null,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        access_token,
        refresh_token,
        token_type: 'Bearer',
        expires_in: process.env.JWT_EXPIRES_IN || '15m',
      },
      'Login successful'
    );
  } catch (error) {
    return next(error);
  }
};

const refresh = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const { refresh_token } = req.body;
    if (!refresh_token) {
      const err = new Error('refresh_token is required');
      err.status = 400;
      throw err;
    }

    const refresh_token_hash = hashToken(refresh_token);
    const session = await sessionModel.findByTokenHash(refresh_token_hash);
    if (!session || session.status !== 'active') {
      const err = new Error('Invalid refresh token');
      err.status = 401;
      throw err;
    }

    if (session.expires_at && new Date(session.expires_at) <= new Date()) {
      await sessionModel.revokeById(session.session_id);
      const err = new Error('Refresh token expired');
      err.status = 401;
      throw err;
    }

    const user = await userModel.findByIdWithMembership(session.user_id, session.organization_id);
    if (!user) {
      const err = new Error('User not found');
      err.status = 401;
      throw err;
    }

    const payload = {
      sub: user.user_id,
      email: user.email,
      org: session.organization_id || null,
      role_id: user.role_id || null,
      role: user.role_key || null,
      name: user.name,
    };

    const access_token = signAccessToken(payload);

    await sessionModel.revokeById(session.session_id);

    const new_refresh_token = generateRefreshToken();
    const new_refresh_hash = hashToken(new_refresh_token);
    const new_expires_at = getRefreshExpiryDate();
    const devicePayload = getDevicePayload(req);

    let deviceId = session.device_id || null;
    if (deviceId) {
      await userDeviceModel.touchDevice(deviceId, devicePayload);
    } else {
      const device = await userDeviceModel.upsertDeviceForLogin({
        user_id: user.user_id,
        ...devicePayload,
      });
      deviceId = device.device_id;
    }

    await sessionModel.createSession({
      user_id: user.user_id,
      organization_id: session.organization_id,
      refresh_token_hash: new_refresh_hash,
      user_agent: devicePayload.user_agent,
      ip_address: devicePayload.ip_address,
      device_id: deviceId,
      expires_at: new_expires_at,
    });

    await logActivitySafe({
      ...buildActorFromRequest(req, {
        actor_id: user.user_id,
        actor_role_key: user.role_key || 'self',
        context_organization_id: session.organization_id || null,
      }),
      ...requestMeta,
      context_organization_id: session.organization_id || null,
      target_type: 'user_session',
      target_id: deviceId || null,
      action: 'auth.refresh',
      action_category: 'auth',
      action_subtype: 'token_refresh',
      description: `Token refreshed for ${user.email}`,
      new_values: {
        user_id: user.user_id,
        organization_id: session.organization_id || null,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        access_token,
        refresh_token: new_refresh_token,
        token_type: 'Bearer',
        expires_in: process.env.JWT_EXPIRES_IN || '15m',
      },
      'Token refreshed'
    );
  } catch (error) {
    return next(error);
  }
};

const logout = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const { refresh_token } = req.body;
    if (!refresh_token) {
      const err = new Error('refresh_token is required');
      err.status = 400;
      throw err;
    }
    const refresh_token_hash = hashToken(refresh_token);
    const existingSession = await sessionModel.findByTokenHash(refresh_token_hash);
    await sessionModel.revokeByTokenHash(refresh_token_hash);
    if (existingSession?.device_id && (await sessionModel.countActiveByDevice(existingSession.device_id)) === 0) {
      await userDeviceModel.markLoggedOut(existingSession.device_id);
    }
    if (existingSession?.user_id) {
      await logActivitySafe({
        ...buildActorFromRequest(req, {
          actor_id: existingSession.user_id,
          actor_role_key: 'self',
          context_organization_id: existingSession.organization_id || null,
        }),
        ...requestMeta,
        context_organization_id: existingSession.organization_id || null,
        target_type: 'user_session',
        target_id: existingSession.session_id || null,
        action: 'auth.logout',
        action_category: 'auth',
        action_subtype: 'logout',
        description: `Logout successful for user ${existingSession.user_id}`,
        new_values: {
          user_id: existingSession.user_id,
          organization_id: existingSession.organization_id || null,
        },
        is_successful: true,
        status: 'success',
      });
    }
    return success(res, null, 'Logged out');
  } catch (error) {
    return next(error);
  }
};

const me = async (req, res, next) => {
  try {
    const tokenUserId = Number(req.user?.sub);
    const orgId = Number(req.user?.org || 0);
    const limitRaw = Number.parseInt(req.query?.limit ?? req.body?.limit, 10);
    const listLimit = Number.isNaN(limitRaw) ? 25 : Math.max(1, Math.min(limitRaw, 100));

    if (!Number.isFinite(tokenUserId) || tokenUserId <= 0) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }

    if (!Number.isFinite(orgId) || orgId <= 0) {
      const err = new Error('Organization context not found in token');
      err.status = 400;
      throw err;
    }

    const userResultPromise = db.query(
      `SELECT
         u.user_id,
         u.email,
         u.name,
         u.profile_url,
         u.mobile,
         u.is_platform_admin,
         u.is_global_member,
         u.email_verified_at,
         u.mobile_verified_at,
         u.last_login_at,
         u.status,
         u.created_at,
         u.updated_at
       FROM users u
       WHERE u.user_id = $1
       LIMIT 1`,
      [tokenUserId]
    );

    const organizationResultPromise = db.query(
      `SELECT
         o.organization_id,
         o.org_key,
         o.name,
         o.subdomain,
         o.custom_domain,
         o.owner_id,
         owner.name AS owner_name,
         owner.email AS owner_email,
         o.language_id,
         lang.language_code,
         lang.full_name AS language_name,
         o.timezone_id,
         tz.timezone_code,
         tz.display_name AS timezone_name,
         o.storage_used_mb,
         o.status,
         o.created_at,
         o.updated_at
       FROM organizations o
       LEFT JOIN users owner ON owner.user_id = o.owner_id
       LEFT JOIN languages lang ON lang.language_id = o.language_id
       LEFT JOIN timezones tz ON tz.timezone_id = o.timezone_id
       WHERE o.organization_id = $1
       LIMIT 1`,
      [orgId]
    );

    const membershipResultPromise = db.query(
      `SELECT
         om.membership_id,
         om.organization_id,
         om.user_id,
         om.role_id,
         r.role_key,
         r.role_name,
         om.department_id,
         d.name AS department_name,
         om.designation_id,
         ds.name AS designation_name,
         om.location_id,
         l.label AS location_name,
         om.status AS membership_status,
         om.joined_at
       FROM organization_members om
       LEFT JOIN roles r ON r.role_id = om.role_id
       LEFT JOIN departments d ON d.department_id = om.department_id
       LEFT JOIN designations ds ON ds.designation_id = om.designation_id
       LEFT JOIN locations l ON l.location_id = om.location_id
       WHERE om.organization_id = $1
         AND om.user_id = $2
       LIMIT 1`,
      [orgId, tokenUserId]
    );

    const subscriptionResultPromise = db.query(
      `SELECT
         s.subscription_id,
         s.organization_id,
         s.plan_id,
         s.status,
         s.start_date,
         s.end_date,
         s.max_users,
         s.max_storage_mb,
         p.plan_key,
         p.plan_name,
         p.interval_days,
         p.price
       FROM subscriptions s
       LEFT JOIN plans p ON p.plan_id = s.plan_id
       WHERE s.organization_id = $1
       ORDER BY s.created_at DESC
       LIMIT 1`,
      [orgId]
    );

    const countsResultPromise = db.query(
      `SELECT
         (SELECT COUNT(*)::int FROM organization_members om WHERE om.organization_id = $1) AS total_members,
         (SELECT COUNT(*)::int FROM organization_members om WHERE om.organization_id = $1 AND om.status = 'active') AS active_members,
         (SELECT COUNT(*)::int FROM user_devices ud WHERE ud.user_id = $2) AS user_devices,
         (SELECT COUNT(*)::int FROM user_sessions us WHERE us.user_id = $2 AND us.organization_id = $1) AS user_sessions,
         (SELECT COUNT(*)::int FROM otp_verifications ov WHERE ov.user_id = $2 AND ov.organization_id = $1) AS otp_verifications,
         (SELECT COUNT(*)::int FROM global_access ga WHERE ga.org_id = $1 AND ga.user_id = $2 AND ga.status = 'active') AS global_access_allowed_users,
         (SELECT COUNT(*)::int FROM global_access ga WHERE ga.org_id = $1 AND ga.allow_user_id = $2 AND ga.status = 'active') AS global_access_received`,
      [orgId, tokenUserId]
    );

    const orgMembersResultPromise = db.query(
      `SELECT
         om.membership_id,
         om.user_id,
         u.name,
         u.email,
         om.role_id,
         r.role_key,
         r.role_name,
         om.status,
         om.joined_at
       FROM organization_members om
       JOIN users u ON u.user_id = om.user_id
       LEFT JOIN roles r ON r.role_id = om.role_id
       WHERE om.organization_id = $1
       ORDER BY om.joined_at DESC
       LIMIT $2`,
      [orgId, listLimit]
    );

    const devicesResultPromise = db.query(
      `SELECT
         device_id,
         device_name,
         device_type,
         ip_address,
         user_agent,
         latitude,
         longitude,
         country,
         city,
         last_active_at,
         is_trusted,
         status
       FROM user_devices
       WHERE user_id = $1
       ORDER BY last_active_at DESC
       LIMIT $2`,
      [tokenUserId, listLimit]
    );

    const sessionsResultPromise = db.query(
      `SELECT
         session_id,
         status,
         created_at,
         last_used_at,
         expires_at,
         revoked_at,
         device_id,
         ip_address,
         user_agent
       FROM user_sessions
       WHERE user_id = $1
         AND organization_id = $2
       ORDER BY created_at DESC
       LIMIT $3`,
      [tokenUserId, orgId, listLimit]
    );

    const otpResultPromise = db.query(
      `SELECT
         otp_id,
         purpose,
         status,
         attempt_count,
         max_attempts,
         created_at,
         expires_at,
         verified_at
       FROM otp_verifications
       WHERE user_id = $1
         AND organization_id = $2
       ORDER BY created_at DESC
       LIMIT $3`,
      [tokenUserId, orgId, listLimit]
    );

    const allowedUsersResultPromise = db.query(
      `SELECT
         ga.global_access_id,
         ga.allow_user_id,
         u.name AS allow_user_name,
         u.email AS allow_user_email,
         ga.status,
         ga.created_at,
         ga.updated_at
       FROM global_access ga
       JOIN users u ON u.user_id = ga.allow_user_id
       WHERE ga.org_id = $1
         AND ga.user_id = $2
       ORDER BY ga.created_at DESC
       LIMIT $3`,
      [orgId, tokenUserId, listLimit]
    );

    const [
      userResult,
      organizationResult,
      membershipResult,
      subscriptionResult,
      countsResult,
      orgMembersResult,
      devicesResult,
      sessionsResult,
      otpResult,
      allowedUsersResult,
    ] = await Promise.all([
      userResultPromise,
      organizationResultPromise,
      membershipResultPromise,
      subscriptionResultPromise,
      countsResultPromise,
      orgMembersResultPromise,
      devicesResultPromise,
      sessionsResultPromise,
      otpResultPromise,
      allowedUsersResultPromise,
    ]);

    if (!userResult.rows.length) {
      const err = new Error('User not found');
      err.status = 404;
      throw err;
    }

    if (!organizationResult.rows.length) {
      const err = new Error('Organization not found');
      err.status = 404;
      throw err;
    }

    if (!membershipResult.rows.length) {
      const err = new Error('Membership not found in organization');
      err.status = 403;
      throw err;
    }

    const user = userResult.rows[0];
    const organization = organizationResult.rows[0];
    const membership = membershipResult.rows[0];
    const currentPlan = subscriptionResult.rows[0]
      ? {
          subscription_id: subscriptionResult.rows[0].subscription_id,
          plan_id: subscriptionResult.rows[0].plan_id,
          plan_key: subscriptionResult.rows[0].plan_key || null,
          plan_name: subscriptionResult.rows[0].plan_name || null,
          subscription_status: subscriptionResult.rows[0].status,
          start_date: subscriptionResult.rows[0].start_date,
          end_date: subscriptionResult.rows[0].end_date,
          interval_days: subscriptionResult.rows[0].interval_days ?? null,
          price: subscriptionResult.rows[0].price ?? null,
          max_users: subscriptionResult.rows[0].max_users,
          max_storage_mb: subscriptionResult.rows[0].max_storage_mb,
        }
      : null;
    const storageUsedMb = Number(organization.storage_used_mb || 0);
    const storageLimitMb = Number(currentPlan?.max_storage_mb || 0);
    const storageUsagePercent =
      storageLimitMb > 0 ? Number(((storageUsedMb / storageLimitMb) * 100).toFixed(2)) : null;
    const counts = countsResult.rows[0] || {};

    return success(
      res,
      {
        user,
        organization: {
          organization_id: organization.organization_id,
          org_key: organization.org_key,
          name: organization.name,
          subdomain: organization.subdomain,
          custom_domain: organization.custom_domain,
          status: organization.status,
          language: {
            language_id: organization.language_id,
            language_code: organization.language_code || null,
            language_name: organization.language_name || null,
          },
          timezone: {
            timezone_id: organization.timezone_id,
            timezone_code: organization.timezone_code || null,
            timezone_name: organization.timezone_name || null,
          },
          created_at: organization.created_at,
          updated_at: organization.updated_at,
        },
        owner: {
          owner_id: organization.owner_id,
          owner_name: organization.owner_name || null,
          owner_email: organization.owner_email || null,
        },
        organization_member: membership,
        user_role: {
          role_id: membership.role_id,
          role_key: membership.role_key || null,
          role_name: membership.role_name || null,
          membership_status: membership.membership_status,
        },
        current_plan: currentPlan,
        usage: {
          storage_used_mb: storageUsedMb,
          storage_limit_mb: storageLimitMb || null,
          storage_usage_percent: storageUsagePercent,
        },
        counts: {
          total_members: Number(counts.total_members || 0),
          active_members: Number(counts.active_members || 0),
          user_devices: Number(counts.user_devices || 0),
          user_sessions: Number(counts.user_sessions || 0),
          otp_verifications: Number(counts.otp_verifications || 0),
          global_access_allowed_users: Number(counts.global_access_allowed_users || 0),
          global_access_received: Number(counts.global_access_received || 0),
        },
        organization_members: orgMembersResult.rows,
        user_devices: devicesResult.rows,
        user_sessions: sessionsResult.rows,
        otp_verifications: otpResult.rows,
        global_access_allowed_users: allowedUsersResult.rows,
        meta: {
          limit: listLimit,
        },
      },
      'Profile'
    );
  } catch (error) {
    return next(error);
  }
};

const getUserDetails = async (req, res, next) => {
  try {
    const tokenUserId = req.user?.sub;
    const orgId = req.user?.org;
    const inputEmail = normalizeEmail(req.body?.email || req.query?.email || '');
    const fullRaw = String(req.body?.full ?? req.query?.full ?? '').toLowerCase();
    const full = ['1', 'true', 'yes'].includes(fullRaw);
    const limitRaw = Number.parseInt(req.body?.limit ?? req.query?.limit, 10);
    const listLimit = Number.isNaN(limitRaw) ? 25 : Math.max(1, Math.min(limitRaw, 100));

    if (!tokenUserId) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }

    if (!orgId) {
      const err = new Error('Organization context not found in token');
      err.status = 400;
      throw err;
    }

    let userId = tokenUserId;
    if (inputEmail) {
      if (!isValidEmail(inputEmail)) {
        const err = new Error('Valid email is required');
        err.status = 400;
        throw err;
      }

      const targetUserResult = await db.query(
        `SELECT u.user_id
         FROM users u
         JOIN organization_members om
           ON om.user_id = u.user_id
          AND om.organization_id = $1
         WHERE LOWER(u.email) = LOWER($2)
         LIMIT 1`,
        [orgId, inputEmail]
      );

      if (!targetUserResult.rows.length) {
        const err = new Error('User not found in this organization');
        err.status = 404;
        throw err;
      }

      userId = targetUserResult.rows[0].user_id;
    }

    const userPromise = db.query(
      `SELECT
         user_id, email, name, mobile, status, email_verified_at, last_login_at
       FROM users
       WHERE user_id = $1
       LIMIT 1`,
      [userId]
    );

    const organizationPromise = db.query(
      `SELECT
         organization_id, org_key, name, subdomain, custom_domain,
         storage_used_mb, status
       FROM organizations
       WHERE organization_id = $1
       LIMIT 1`,
      [orgId]
    );

    const membershipPromise = db.query(
      `SELECT
         om.membership_id, om.organization_id, om.user_id, om.role_id, om.status, om.joined_at,
         r.role_key, r.role_name
       FROM organization_members om
       LEFT JOIN roles r ON r.role_id = om.role_id
       WHERE om.organization_id = $1
         AND om.user_id = $2
       LIMIT 1`,
      [orgId, userId]
    );

    const subscriptionPromise = db.query(
      `SELECT
         s.subscription_id, s.organization_id, s.plan_id, s.status, s.start_date, s.end_date,
         s.max_users, s.max_storage_mb,
         p.plan_key, p.plan_name, p.interval_days, p.price
       FROM subscriptions s
       LEFT JOIN plans p ON p.plan_id = s.plan_id
       WHERE s.organization_id = $1
       ORDER BY s.created_at DESC
       LIMIT 1`,
      [orgId]
    );

    const membersPromise = full
      ? db.query(
        `SELECT
             om.membership_id, om.organization_id, om.user_id, om.role_id, om.status, om.joined_at,
             u.name, u.email, r.role_key, r.role_name
           FROM organization_members om
           JOIN users u ON u.user_id = om.user_id
           LEFT JOIN roles r ON r.role_id = om.role_id
           WHERE om.organization_id = $1
           ORDER BY om.joined_at DESC
           LIMIT $2`,
        [orgId, listLimit]
      )
      : db.query(
        `SELECT COUNT(*)::int AS total
           FROM organization_members
           WHERE organization_id = $1`,
        [orgId]
      );

    const devicesPromise = full
      ? db.query(
        `SELECT
         device_id, device_name, device_type, ip_address,
         last_active_at, is_trusted, status
       FROM user_devices
       WHERE user_id = $1
       ORDER BY last_active_at DESC
       LIMIT $2`,
        [userId, listLimit]
      )
      : db.query(
        `SELECT COUNT(*)::int AS total
           FROM user_devices
           WHERE user_id = $1`,
        [userId]
      );

    const sessionsPromise = full
      ? db.query(
        `SELECT
         session_id, status, created_at, last_used_at,
         expires_at, revoked_at, device_id, ip_address
       FROM user_sessions
       WHERE user_id = $1
         AND organization_id = $2
       ORDER BY created_at DESC
       LIMIT $3`,
        [userId, orgId, listLimit]
      )
      : db.query(
        `SELECT COUNT(*)::int AS total
           FROM user_sessions
           WHERE user_id = $1
             AND organization_id = $2`,
        [userId, orgId]
      );

    const otpPromise = full
      ? db.query(
        `SELECT
         otp_id, purpose, status, attempt_count, max_attempts,
         created_at, expires_at, verified_at
       FROM otp_verifications
       WHERE user_id = $1
         AND organization_id = $2
       ORDER BY created_at DESC
       LIMIT $3`,
        [userId, orgId, listLimit]
      )
      : db.query(
        `SELECT COUNT(*)::int AS total
           FROM otp_verifications
           WHERE user_id = $1
             AND organization_id = $2`,
        [userId, orgId]
      );

    const [
      userResult,
      organizationResult,
      membershipResult,
      membersResult,
      subscriptionResult,
      devicesResult,
      sessionsResult,
      otpResult,
    ] = await Promise.all([
      userPromise,
      organizationPromise,
      membershipPromise,
      membersPromise,
      subscriptionPromise,
      devicesPromise,
      sessionsPromise,
      otpPromise,
    ]);

    if (!userResult.rows.length) {
      const err = new Error('User not found');
      err.status = 404;
      throw err;
    }

    if (!organizationResult.rows.length) {
      const err = new Error('Organization not found');
      err.status = 404;
      throw err;
    }

    const organizationMember = membershipResult.rows[0] || null;
    const subscription = subscriptionResult.rows[0] || null;
    const currentPlan = subscription
      ? {
        plan_id: subscription.plan_id,
        plan_key: subscription.plan_key || null,
        plan_name: subscription.plan_name || null,
        status: subscription.status,
        start_date: subscription.start_date,
        end_date: subscription.end_date,
        interval_days: subscription.interval_days ?? null,
        price: subscription.price ?? null,
      }
      : null;
    const userRole = organizationMember
      ? {
        role_id: organizationMember.role_id,
        role_key: organizationMember.role_key || null,
        role_name: organizationMember.role_name || null,
        membership_status: organizationMember.status,
      }
      : null;

    if (!full) {
      return success(
        res,
        {
          user: {
            user_id: userResult.rows[0].user_id,
            email: userResult.rows[0].email,
            name: userResult.rows[0].name,
            status: userResult.rows[0].status,
          },
          organization: {
            organization_id: organizationResult.rows[0].organization_id,
            name: organizationResult.rows[0].name,
            custom_domain: organizationResult.rows[0].custom_domain,
            status: organizationResult.rows[0].status,
          },
          current_plan: currentPlan,
          user_role: userRole,
          counts: {
            organization_members: membersResult.rows[0]?.total || 0,
            user_devices: devicesResult.rows[0]?.total || 0,
            user_sessions: sessionsResult.rows[0]?.total || 0,
            otp_verifications: otpResult.rows[0]?.total || 0,
          },
        },
        'User details retrieved'
      );
    }

    return success(
      res,
      {
        user: userResult.rows[0],
        organization: organizationResult.rows[0],
        organization_member: organizationMember,
        user_role: userRole,
        organization_members: membersResult.rows,
        subscription,
        current_plan: currentPlan,
        user_devices: devicesResult.rows,
        user_sessions: sessionsResult.rows,
        otp_verifications: otpResult.rows,
        meta: {
          limit: listLimit,
        },
      },
      'User details retrieved'
    );
  } catch (error) {
    return next(error);
  }
};

const getOrganizationDetails = async (req, res, next) => {
  try {
    const requestMeta = buildRequestMeta(req);
    const tokenUserId = Number(req.user?.sub);
    const tokenOrgId = Number(req.user?.org);
    const requestedOrgId = Number(req.query?.organization_id || req.body?.organization_id);
    const organizationId =
      Number.isFinite(requestedOrgId) && requestedOrgId > 0 ? requestedOrgId : tokenOrgId;

    if (!Number.isFinite(tokenUserId) || tokenUserId <= 0) {
      const err = new Error('Unauthorized');
      err.status = 401;
      throw err;
    }

    if (!Number.isFinite(organizationId) || organizationId <= 0) {
      const err = new Error('Valid organization_id is required');
      err.status = 400;
      throw err;
    }

    const membershipAccess = await db.query(
      `SELECT membership_id
       FROM organization_members
       WHERE organization_id = $1
         AND user_id = $2
         AND status = 'active'
       LIMIT 1`,
      [organizationId, tokenUserId]
    );

    if (!membershipAccess.rows.length) {
      const err = new Error('Access denied for requested organization');
      err.status = 403;
      throw err;
    }

    const organizationPromise = db.query(
      `SELECT
         o.organization_id,
         o.org_key,
         o.name,
         o.subdomain,
         o.custom_domain,
         o.owner_id,
         owner.name AS owner_name,
         owner.email AS owner_email,
         o.language_id,
         o.timezone_id,
         o.storage_used_mb,
         o.status,
         o.created_at,
         o.updated_at
       FROM organizations o
       LEFT JOIN users owner ON owner.user_id = o.owner_id
       WHERE o.organization_id = $1
       LIMIT 1`,
      [organizationId]
    );

    const subscriptionPromise = db.query(
      `SELECT
         s.subscription_id,
         s.organization_id,
         s.plan_id,
         s.status,
         s.start_date,
         s.end_date,
         s.max_users,
         s.max_storage_mb,
         p.plan_key,
         p.plan_name,
         p.interval_days,
         p.price
       FROM subscriptions s
       LEFT JOIN plans p ON p.plan_id = s.plan_id
       WHERE s.organization_id = $1
       ORDER BY s.created_at DESC
       LIMIT 1`,
      [organizationId]
    );

    const memberStatsPromise = db.query(
      `SELECT
         COUNT(*)::int AS total_members,
         COUNT(*) FILTER (WHERE om.status = 'active')::int AS active_members,
         COUNT(*) FILTER (WHERE om.status = 'invited')::int AS invited_members,
         COUNT(*) FILTER (WHERE om.status = 'suspended')::int AS suspended_members,
         COUNT(*) FILTER (WHERE om.status = 'left')::int AS left_members,
         COUNT(*) FILTER (WHERE u.is_global_member = TRUE)::int AS global_members,
         COUNT(*) FILTER (WHERE u.is_platform_admin = TRUE)::int AS platform_admin_members
       FROM organization_members om
       JOIN users u ON u.user_id = om.user_id
       WHERE om.organization_id = $1`,
      [organizationId]
    );

    const roleStatsPromise = db.query(
      `SELECT
         r.role_id,
         r.role_key,
         r.role_name,
         COUNT(*)::int AS total
       FROM organization_members om
       LEFT JOIN roles r ON r.role_id = om.role_id
       WHERE om.organization_id = $1
       GROUP BY r.role_id, r.role_key, r.role_name
       ORDER BY total DESC, r.role_id ASC`,
      [organizationId]
    );

    const structureStatsPromise = db.query(
      `SELECT
         (SELECT COUNT(*)::int FROM departments d WHERE d.organization_id = $1) AS departments,
         (SELECT COUNT(*)::int FROM designations ds WHERE ds.organization_id = $1) AS designations,
         (SELECT COUNT(*)::int FROM locations l WHERE l.organization_id = $1) AS locations`,
      [organizationId]
    );

    const activityStatsPromise = db.query(
      `SELECT COUNT(*)::int AS total_activity_logs
       FROM activity_log
       WHERE context_organization_id = $1`,
      [organizationId]
    );

    const [organizationResult, subscriptionResult, memberStatsResult, roleStatsResult, structureStatsResult, activityStatsResult] =
      await Promise.all([
        organizationPromise,
        subscriptionPromise,
        memberStatsPromise,
        roleStatsPromise,
        structureStatsPromise,
        activityStatsPromise,
      ]);

    if (!organizationResult.rows.length) {
      const err = new Error('Organization not found');
      err.status = 404;
      throw err;
    }

    const organization = organizationResult.rows[0];
    const subscription = subscriptionResult.rows[0] || null;
    const memberStats = memberStatsResult.rows[0] || {};
    const structureStats = structureStatsResult.rows[0] || {};
    const totalActivityLogs = Number(activityStatsResult.rows[0]?.total_activity_logs || 0);
    const usedStorageMb = Number(organization.storage_used_mb || 0);
    const maxStorageMb = Number(subscription?.max_storage_mb || 0);
    const storageUsagePercent =
      maxStorageMb > 0 ? Number(((usedStorageMb / maxStorageMb) * 100).toFixed(2)) : null;

    await logActivitySafe({
      ...buildActorFromRequest(req, { context_organization_id: organizationId }),
      ...requestMeta,
      context_organization_id: organizationId,
      target_type: 'organization',
      target_id: organizationId,
      action: 'organization.details.view',
      action_category: 'organization_management',
      action_subtype: 'organization_summary_read',
      description: `Organization details viewed for organization ${organizationId}`,
      new_values: {
        organization_id: organizationId,
      },
      is_successful: true,
      status: 'success',
    });

    return success(
      res,
      {
        organization: {
          organization_id: organization.organization_id,
          org_key: organization.org_key,
          name: organization.name,
          subdomain: organization.subdomain,
          custom_domain: organization.custom_domain,
          status: organization.status,
          created_at: organization.created_at,
          updated_at: organization.updated_at,
        },
        owner: {
          owner_id: organization.owner_id,
          owner_name: organization.owner_name || null,
          owner_email: organization.owner_email || null,
        },
        current_plan: subscription
          ? {
              subscription_id: subscription.subscription_id,
              plan_id: subscription.plan_id,
              plan_key: subscription.plan_key || null,
              plan_name: subscription.plan_name || null,
              subscription_status: subscription.status,
              start_date: subscription.start_date,
              end_date: subscription.end_date,
              interval_days: subscription.interval_days ?? null,
              price: subscription.price ?? null,
              max_users: subscription.max_users,
              max_storage_mb: subscription.max_storage_mb,
            }
          : null,
        usage: {
          storage_used_mb: usedStorageMb,
          storage_limit_mb: maxStorageMb || null,
          storage_usage_percent: storageUsagePercent,
        },
        counts: {
          total_members: Number(memberStats.total_members || 0),
          active_members: Number(memberStats.active_members || 0),
          invited_members: Number(memberStats.invited_members || 0),
          suspended_members: Number(memberStats.suspended_members || 0),
          left_members: Number(memberStats.left_members || 0),
          global_members: Number(memberStats.global_members || 0),
          platform_admin_members: Number(memberStats.platform_admin_members || 0),
          departments: Number(structureStats.departments || 0),
          designations: Number(structureStats.designations || 0),
          locations: Number(structureStats.locations || 0),
          total_activity_logs: totalActivityLogs,
        },
        role_distribution: roleStatsResult.rows.map((row) => ({
          role_id: row.role_id,
          role_key: row.role_key,
          role_name: row.role_name,
          total: Number(row.total || 0),
        })),
      },
      'Organization details retrieved'
    );
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  register,
  createNewAccount,
  resendOtp,
  forgotPassword,
  verifyForgotPasswordOtp,
  resetPassword,
  verifyOtp,
  login,
  refresh,
  logout,
  me,
  getUserDetails,
  getOrganizationDetails,
};
