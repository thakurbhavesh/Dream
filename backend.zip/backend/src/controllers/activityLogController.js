const db = require('../config/database');
const activityLogModel = require('../models/activityLogModel');
const { success } = require('../utils/response');
const { parsePagination, parseSearch } = require('../utils/common/common_function');

const resolveOrganizationId = async (req) => {
  const tokenOrgId = Number(req.user?.org);
  const requestedOrgId = Number(req.query?.organization_id || req.body?.organization_id);
  const orgId = Number.isFinite(requestedOrgId) && requestedOrgId > 0 ? requestedOrgId : tokenOrgId;

  if (!Number.isFinite(orgId) || orgId <= 0) {
    const err = new Error('Valid organization context is required');
    err.status = 400;
    throw err;
  }

  const requesterUserId = Number(req.user?.sub);
  if (!Number.isFinite(requesterUserId) || requesterUserId <= 0) {
    const err = new Error('Unauthorized');
    err.status = 401;
    throw err;
  }

  const membershipResult = await db.query(
    `SELECT membership_id
     FROM organization_members
     WHERE organization_id = $1
       AND user_id = $2
       AND status = 'active'
     LIMIT 1`,
    [orgId, requesterUserId]
  );

  if (!membershipResult.rows.length) {
    const err = new Error('Access denied for requested organization');
    err.status = 403;
    throw err;
  }

  return orgId;
};

const parseBool = (value) => {
  if (value === undefined || value === null || value === '') return undefined;
  const normalized = String(value).trim().toLowerCase();
  if (['1', 'true', 'yes'].includes(normalized)) return true;
  if (['0', 'false', 'no'].includes(normalized)) return false;
  return undefined;
};

const getActivityLogs = async (req, res, next) => {
  try {
    const context_organization_id = await resolveOrganizationId(req);
    const { limit, offset } = parsePagination(req.query);
    const search = parseSearch(req.query);

    const userIdRaw = req.query.user_id ?? req.body?.user_id;
    const actorIdRaw = req.query.actor_id ?? req.body?.actor_id;
    const user_id = userIdRaw !== undefined ? Number(userIdRaw) : undefined;
    const actor_id = actorIdRaw !== undefined ? Number(actorIdRaw) : undefined;

    if (userIdRaw !== undefined && (!Number.isFinite(user_id) || user_id <= 0)) {
      const err = new Error('user_id must be a positive number');
      err.status = 400;
      throw err;
    }

    if (actorIdRaw !== undefined && (!Number.isFinite(actor_id) || actor_id <= 0)) {
      const err = new Error('actor_id must be a positive number');
      err.status = 400;
      throw err;
    }

    const occurred_from = req.query.occurred_from || req.body?.occurred_from;
    const occurred_to = req.query.occurred_to || req.body?.occurred_to;
    const action = req.query.action || req.body?.action;
    const status = req.query.status || req.body?.status;
    const is_successful = parseBool(req.query.is_successful ?? req.body?.is_successful);

    const { rows, total } = await activityLogModel.findActivityLogs({
      context_organization_id,
      user_id,
      actor_id,
      action,
      status,
      is_successful,
      search,
      occurred_from,
      occurred_to,
      limit,
      offset,
    });

    const formattedRows = rows.map((item) => ({
      log_id: item.log_id,
      occurred_at: item.occurred_at,
      status: item.status,
      is_successful: item.is_successful,
      action: item.action,
      action_category: item.action_category,
      action_subtype: item.action_subtype,
      description: item.description,
      organization: {
        organization_id: item.context_organization_id,
        name: item.context_organization_name || null,
      },
      user: {
        user_id: item.target_type === 'user' ? item.target_id : item.actor_id,
        name: item.user_name || null,
        email: item.user_email || null,
      },
      actor: {
        actor_id: item.actor_id,
        role_key: item.actor_role_key,
        name: item.actor_name || null,
        email: item.actor_email || null,
      },
      target: {
        type: item.target_type,
        id: item.target_id,
        name: item.target_user_name || null,
        email: item.target_user_email || null,
      },
      changes: {
        old_values: item.old_values || null,
        new_values: item.new_values || null,
      },
      request_meta: {
        ip_address: item.ip_address || null,
        user_agent: item.user_agent || null,
      },
    }));

    return success(
      res,
      {
        count: total,
        rows: formattedRows,
      },
      'Activity logs retrieved'
    );
  } catch (error) {
    return next(error);
  }
};

module.exports = {
  getActivityLogs,
};
