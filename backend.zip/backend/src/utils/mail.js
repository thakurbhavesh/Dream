const nodemailer = require('nodemailer');
const dotenv = require('dotenv');

dotenv.config();

let transporter;
const DEFAULT_MAIL_TIMEOUT_MS = 5000;

const getRequiredEnv = (key) => {
  const value = process.env[key];
  if (!value) {
    const err = new Error(`${key} is required for SMTP`);
    err.status = 500;
    throw err;
  }
  return value;
};

const getTransporter = () => {
  if (transporter) return transporter;

  const host = getRequiredEnv('SMTP_HOST');
  const port = Number(getRequiredEnv('SMTP_PORT'));
  const user = getRequiredEnv('SMTP_USER');
  const pass = getRequiredEnv('SMTP_PASS');
  const secure = String(process.env.SMTP_SECURE || 'false') === 'true';
  const timeoutMs = Number(process.env.SMTP_TIMEOUT_MS || DEFAULT_MAIL_TIMEOUT_MS);

  transporter = nodemailer.createTransport({
    host,
    port,
    secure,
    pool: true,
    maxConnections: Number(process.env.SMTP_MAX_CONNECTIONS || 5),
    maxMessages: Number(process.env.SMTP_MAX_MESSAGES || 100),
    connectionTimeout: timeoutMs,
    greetingTimeout: timeoutMs,
    socketTimeout: timeoutMs,
    auth: { user, pass },
  });

  return transporter;
};

const sendMail = async ({ to, subject, text, html, replyTo, cc, bcc }) => {
  const from = process.env.SMTP_FROM || getRequiredEnv('SMTP_USER');
  const tx = getTransporter();
  return tx.sendMail({ from, to, subject, text, html, replyTo, cc, bcc });
};

const sendMailAsync = (payload, options = {}) => {
  const { onSuccess, onError } = options;
  const promise = new Promise((resolve, reject) => {
    setImmediate(async () => {
      try {
        const info = await sendMail(payload);
        if (typeof onSuccess === 'function') onSuccess(info);
        resolve(info);
      } catch (error) {
        if (typeof onError === 'function') {
          onError(error);
        } else {
          console.error('Async mail send failed', {
            message: error.message,
            to: payload?.to,
            subject: payload?.subject,
          });
        }
        reject(error);
      }
    });
  });

  // Avoid unhandled rejection when caller intentionally fire-and-forgets.
  promise.catch(() => {});
  return promise;
};

module.exports = {
  sendMail,
  sendMailAsync,
};
