const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
const helmet = require('helmet');
const errorHandler = require('./middlewares/errorHandler');
const authRoutes = require('./routes/authRoutes');
const roleRoutes = require('./routes/roleRoutes');
const planRoutes = require('./routes/planRoutes');
const languageRoutes = require('./routes/languageRoutes');
const timezoneRoutes = require('./routes/timezoneRoutes');
const platformRoutes = require('./routes/platformRoutes');
const messageMenuItemRoutes = require('./routes/messageMenuItemRoutes');
const departmentRoutes = require('./routes/departmentRoutes');
const designationRoutes = require('./routes/designationRoutes');
const locationRoutes = require('./routes/locationRoutes');
const orgUserRoutes = require('./routes/orgUserRoutes');
const activityLogRoutes = require('./routes/activityLogRoutes');
const globalAccessRoutes = require('./routes/globalAccessRoutes');
const groupRoutes = require('./routes/groupRoutes');
const groupMemberRoutes = require('./routes/groupMemberRoutes');
const groupTimelineRoutes = require('./routes/groupTimelineRoutes');
const organizationMessageMenuPermissionRoutes = require('./routes/organizationMessageMenuPermissionRoutes');
const planFeatureRoutes = require('./routes/planFeatureRoutes');
const siteDetailRoutes = require('./routes/siteDetailRoutes');
const productFeatureRoutes = require('./routes/productFeatureRoutes');
const contactUsRoutes = require('./routes/contactUsRoutes');
const organizationRestrictionRoutes = require('./routes/organizationRestrictionRoutes');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('dev'));
}

app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/auth', authRoutes);
app.use('/roles', roleRoutes);
app.use('/plans', planRoutes);
app.use('/languages', languageRoutes);
app.use('/timezones', timezoneRoutes);
app.use('/platforms', platformRoutes);
app.use('/message-menu-items', messageMenuItemRoutes);
app.use('/departments', departmentRoutes);
app.use('/designations', designationRoutes);
app.use('/locations', locationRoutes);
app.use('/users', orgUserRoutes);
app.use('/activity-logs', activityLogRoutes);
app.use('/global-access', globalAccessRoutes);
app.use('/groups', groupRoutes);
app.use('/group-members', groupMemberRoutes);
app.use('/group-timeline', groupTimelineRoutes);
app.use('/organization-message-menu-permissions', organizationMessageMenuPermissionRoutes);
app.use('/plan-features', planFeatureRoutes);
app.use('/site-details', siteDetailRoutes);
app.use('/product-features', productFeatureRoutes);
app.use('/contact-us', contactUsRoutes);
app.use('/organization-restrictions', organizationRestrictionRoutes);


app.use((req, res, next) => {
  const error = new Error('Route not found');
  error.status = 404;
  next(error);
});

app.use(errorHandler);

module.exports = app;
