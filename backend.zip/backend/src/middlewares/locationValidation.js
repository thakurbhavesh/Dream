const { failure } = require('../utils/response');

const isMissing = (value) =>
  value === undefined || value === null || (typeof value === 'string' && value.trim() === '');

const validateLocationPayload = (req, res, next) => {
  const { organization_id, label, status } = req.body || {};

  if (isMissing(organization_id) || isMissing(label)) {
    return failure(res, 'organization_id and label are required', 400);
  }

  if (status && !['active', 'inactive'].includes(status)) {
    return failure(res, 'status must be active or inactive', 400);
  }

  return next();
};

const validateLocationUpdate = (req, res, next) => {
  const { status } = req.body || {};

  if (status && !['active', 'inactive'].includes(status)) {
    return failure(res, 'status must be active or inactive', 400);
  }

  return next();
};

module.exports = {
  validateLocationPayload,
  validateLocationUpdate,
};
