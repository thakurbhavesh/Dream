const { failure } = require('../utils/response');

const isMissing = (value) =>
  value === undefined || value === null || (typeof value === 'string' && value.trim() === '');

const validateDesignationPayload = (req, res, next) => {
  const { organization_id, department_id, name, status } = req.body || {};

  if (isMissing(organization_id) || isMissing(department_id) || isMissing(name)) {
    return failure(res, 'organization_id, department_id and name are required', 400);
  }

  if (status && !['active', 'inactive'].includes(status)) {
    return failure(res, 'status must be active or inactive', 400);
  }

  return next();
};

const validateDesignationUpdate = (req, res, next) => {
  const { status } = req.body || {};

  if (status && !['active', 'inactive'].includes(status)) {
    return failure(res, 'status must be active or inactive', 400);
  }

  return next();
};

module.exports = {
  validateDesignationPayload,
  validateDesignationUpdate,
};
