const { getVerificationOtpMailTemplate } = require('./auth/verificationOtpTemplate');
const { getForgotPasswordOtpMailTemplate } = require('./auth/forgotPasswordOtpTemplate');
const { getPasswordResetSuccessMailTemplate } = require('./auth/passwordResetSuccessTemplate');
const { getOrgUserAccountCreatedMailTemplate } = require('./orgUser/accountCreatedTemplate');
const { getOrgUserPasswordResetMailTemplate } = require('./orgUser/passwordResetTemplate');
const { getContactUsAdminNotificationTemplate } = require('./contactUs/adminNotificationTemplate');
const {
  getContactUsCustomerAcknowledgementTemplate,
} = require('./contactUs/customerAcknowledgementTemplate');

module.exports = {
  getVerificationOtpMailTemplate,
  getForgotPasswordOtpMailTemplate,
  getPasswordResetSuccessMailTemplate,
  getOrgUserAccountCreatedMailTemplate,
  getOrgUserPasswordResetMailTemplate,
  getContactUsAdminNotificationTemplate,
  getContactUsCustomerAcknowledgementTemplate,
};

