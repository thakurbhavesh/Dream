# Mail Templates Map

All email templates are centralized under `src/templates/mail/`.

## Auth
- `auth/verificationOtpTemplate.js`
- `auth/forgotPasswordOtpTemplate.js`
- `auth/passwordResetSuccessTemplate.js`

## Organization Users
- `orgUser/accountCreatedTemplate.js`
- `orgUser/passwordResetTemplate.js`

## Contact Us
- `contactUs/adminNotificationTemplate.js`
- `contactUs/customerAcknowledgementTemplate.js`

Shared export entry:
- `src/templates/mail/index.js`

## Update Log (2026-02-27)

- Templates split by domain (`auth`, `orgUser`, `contactUs`) for easier maintenance.
- Controllers now consume templates from `src/templates/mail/index.js`.
- Organization restrictions module added without new mail templates.
- Added password reset success template for post-reset security confirmation emails.

