const { Router } = require('express');
const authController = require('../controllers/authController');
const auth = require('../middlewares/auth');
const requireNotRoleId = require('../middlewares/requireNotRoleId');

const router = Router();
const blockRole4 = requireNotRoleId(4);

router.post('/register', authController.register);
router.post('/create-account', authController.createNewAccount);
router.post('/resend-otp', authController.resendOtp);
router.post('/forgot-password', authController.forgotPassword);
router.post('/reset-password', authController.resetPassword);
router.post('/forgot-verify', authController.verifyForgotPasswordOtp);
router.post('/verify-otp', authController.verifyOtp);
router.post('/login', authController.login);
router.post('/refresh', authController.refresh);
router.post('/logout', authController.logout);
router.get('/me', auth, authController.me);
router.get('/user-details', auth, blockRole4, authController.getUserDetails);
router.post('/user-details', auth, blockRole4, authController.getUserDetails);
router.get('/organization-details', auth, blockRole4, authController.getOrganizationDetails);

module.exports = router;
