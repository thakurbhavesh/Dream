const db = require('../config/database');

const sanitizeDeviceType = (value) => {
  const allowed = new Set(['mobile', 'desktop', 'tablet', 'other']);
  if (!value || typeof value !== 'string') return 'other';
  const normalized = value.trim().toLowerCase();
  return allowed.has(normalized) ? normalized : 'other';
};

const findLatestByFingerprint = async ({ user_id, ip_address, user_agent }) => {
  if (!user_id || !ip_address) return null;

  const query = `
    SELECT *
    FROM user_devices
    WHERE user_id = $1
      AND ip_address = $2
      AND COALESCE(user_agent, '') = COALESCE($3, '')
    ORDER BY last_active_at DESC
    LIMIT 1
  `;

  const { rows } = await db.query(query, [user_id, ip_address, user_agent || null]);
  return rows[0];
};

const createDevice = async ({
  user_id,
  device_name,
  device_type,
  ip_address,
  user_agent,
  latitude,
  longitude,
  accuracy_radius,
  country,
  city,
}) => {
  const query = `
    INSERT INTO user_devices (
      user_id,
      device_name,
      device_type,
      ip_address,
      user_agent,
      latitude,
      longitude,
      accuracy_radius,
      country,
      city,
      status,
      last_active_at
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'active', NOW())
    RETURNING *
  `;

  const values = [
    user_id,
    device_name || null,
    sanitizeDeviceType(device_type),
    ip_address,
    user_agent || null,
    latitude ?? null,
    longitude ?? null,
    accuracy_radius ?? null,
    country || null,
    city || null,
  ];

  const { rows } = await db.query(query, values);
  return rows[0];
};

const touchDevice = async (
  device_id,
  { device_name, device_type, latitude, longitude, accuracy_radius, country, city }
) => {
  const query = `
    UPDATE user_devices
    SET
      device_name = COALESCE($1, device_name),
      device_type = COALESCE($2, device_type),
      latitude = COALESCE($3, latitude),
      longitude = COALESCE($4, longitude),
      accuracy_radius = COALESCE($5, accuracy_radius),
      country = COALESCE($6, country),
      city = COALESCE($7, city),
      status = 'active',
      last_active_at = NOW()
    WHERE device_id = $8
    RETURNING *
  `;

  const values = [
    device_name || null,
    device_type ? sanitizeDeviceType(device_type) : null,
    latitude ?? null,
    longitude ?? null,
    accuracy_radius ?? null,
    country || null,
    city || null,
    device_id,
  ];

  const { rows } = await db.query(query, values);
  return rows[0];
};

const upsertDeviceForLogin = async ({
  user_id,
  device_name,
  device_type,
  ip_address,
  user_agent,
  latitude,
  longitude,
  accuracy_radius,
  country,
  city,
}) => {
  const existing = await findLatestByFingerprint({ user_id, ip_address, user_agent });

  if (existing) {
    return touchDevice(existing.device_id, {
      device_name,
      device_type,
      latitude,
      longitude,
      accuracy_radius,
      country,
      city,
    });
  }

  return createDevice({
    user_id,
    device_name,
    device_type,
    ip_address,
    user_agent,
    latitude,
    longitude,
    accuracy_radius,
    country,
    city,
  });
};

const markLoggedOut = async (device_id) => {
  if (!device_id) return;
  await db.query(
    `UPDATE user_devices
     SET status = 'logged_out', last_active_at = NOW()
     WHERE device_id = $1`,
    [device_id]
  );
};

module.exports = {
  upsertDeviceForLogin,
  touchDevice,
  markLoggedOut,
};
