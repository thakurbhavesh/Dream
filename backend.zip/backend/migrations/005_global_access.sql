CREATE TABLE IF NOT EXISTS global_access (
    global_access_id BIGSERIAL PRIMARY KEY,
    org_id           BIGINT NOT NULL,
    user_id          BIGINT NOT NULL,
    allow_user_id    BIGINT NOT NULL,
    status           VARCHAR(20) NOT NULL DEFAULT 'active'
      CHECK (status IN ('active', 'inactive')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_global_access UNIQUE (org_id, user_id, allow_user_id),
    CONSTRAINT fk_global_access_org
      FOREIGN KEY (org_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_global_access_user
      FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_global_access_allow_user
      FOREIGN KEY (allow_user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT chk_global_access_not_self CHECK (user_id <> allow_user_id)
);

CREATE INDEX IF NOT EXISTS idx_global_access_org_id
  ON global_access (org_id);

CREATE INDEX IF NOT EXISTS idx_global_access_user_id
  ON global_access (user_id);

CREATE INDEX IF NOT EXISTS idx_global_access_allow_user_id
  ON global_access (allow_user_id);

CREATE OR REPLACE FUNCTION validate_global_access()
RETURNS TRIGGER AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM users u
    WHERE u.user_id = NEW.user_id
      AND u.is_global_member = TRUE
  ) THEN
    RAISE EXCEPTION 'user_id % is not a global member', NEW.user_id;
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM organization_members om
    WHERE om.organization_id = NEW.org_id
      AND om.user_id = NEW.allow_user_id
      AND om.status = 'active'
  ) THEN
    RAISE EXCEPTION 'allow_user_id % is not an active member of organization %', NEW.allow_user_id, NEW.org_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_validate_global_access ON global_access;

CREATE TRIGGER trg_validate_global_access
BEFORE INSERT OR UPDATE ON global_access
FOR EACH ROW
EXECUTE FUNCTION validate_global_access();
