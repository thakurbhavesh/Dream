-- Speed up group lookup by case-insensitive name with optional org filter.

CREATE INDEX IF NOT EXISTS idx_groups_lower_name_org
  ON groups (LOWER(group_name), organization_id);
