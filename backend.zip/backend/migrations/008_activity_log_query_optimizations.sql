-- Additional indexes to speed up /activity-logs filters on large datasets.

CREATE INDEX IF NOT EXISTS idx_activity_log_org_status_time_desc
  ON activity_log (context_organization_id, status, occurred_at DESC);

CREATE INDEX IF NOT EXISTS idx_activity_log_target_user
  ON activity_log (target_type, target_id);
