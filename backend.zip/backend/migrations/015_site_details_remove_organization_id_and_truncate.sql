TRUNCATE TABLE
  site_detail_addresses,
  site_detail_phones,
  site_detail_emails,
  site_details
RESTART IDENTITY;

ALTER TABLE site_details
  DROP CONSTRAINT IF EXISTS fk_site_details_org;

ALTER TABLE site_details
  DROP CONSTRAINT IF EXISTS site_details_organization_id_fkey;

DROP INDEX IF EXISTS idx_site_details_org_id;

ALTER TABLE site_details
  DROP COLUMN IF EXISTS organization_id;
