CREATE TABLE IF NOT EXISTS site_details (
    site_detail_id    BIGSERIAL PRIMARY KEY,
    organization_id   BIGINT NOT NULL UNIQUE,
    brand_name        VARCHAR(150) NOT NULL,
    logo_url          TEXT,
    mascot_url        TEXT,
    google_plus_url   TEXT,
    linkedin_url      TEXT,
    twitter_url       TEXT,
    youtube_url       TEXT,
    status            VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_site_details_org
      FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_site_details_org_id
  ON site_details (organization_id);

CREATE TABLE IF NOT EXISTS site_detail_emails (
    site_detail_email_id BIGSERIAL PRIMARY KEY,
    site_detail_id       BIGINT NOT NULL,
    email_address        VARCHAR(255) NOT NULL,
    label                VARCHAR(50),
    is_primary           BOOLEAN NOT NULL DEFAULT FALSE,
    status               VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_site_detail_emails_site_detail
      FOREIGN KEY (site_detail_id) REFERENCES site_details(site_detail_id) ON DELETE CASCADE,
    CONSTRAINT uk_site_detail_emails_unique
      UNIQUE (site_detail_id, email_address)
);

CREATE INDEX IF NOT EXISTS idx_site_detail_emails_site_detail_id
  ON site_detail_emails (site_detail_id);

CREATE TABLE IF NOT EXISTS site_detail_phones (
    site_detail_phone_id BIGSERIAL PRIMARY KEY,
    site_detail_id       BIGINT NOT NULL,
    phone_number         VARCHAR(30) NOT NULL,
    label                VARCHAR(50),
    is_primary           BOOLEAN NOT NULL DEFAULT FALSE,
    status               VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_site_detail_phones_site_detail
      FOREIGN KEY (site_detail_id) REFERENCES site_details(site_detail_id) ON DELETE CASCADE,
    CONSTRAINT uk_site_detail_phones_unique
      UNIQUE (site_detail_id, phone_number)
);

CREATE INDEX IF NOT EXISTS idx_site_detail_phones_site_detail_id
  ON site_detail_phones (site_detail_id);

CREATE TABLE IF NOT EXISTS site_detail_addresses (
    site_detail_address_id BIGSERIAL PRIMARY KEY,
    site_detail_id         BIGINT NOT NULL,
    label                  VARCHAR(50),
    address_line_1         VARCHAR(255) NOT NULL,
    address_line_2         VARCHAR(255),
    city                   VARCHAR(100),
    state                  VARCHAR(100),
    country                VARCHAR(100),
    postal_code            VARCHAR(20),
    is_primary             BOOLEAN NOT NULL DEFAULT FALSE,
    status                 VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_site_detail_addresses_site_detail
      FOREIGN KEY (site_detail_id) REFERENCES site_details(site_detail_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_site_detail_addresses_site_detail_id
  ON site_detail_addresses (site_detail_id);
