ALTER TABLE organization_members
ADD COLUMN IF NOT EXISTS location_id BIGINT;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_mem_location'
  ) THEN
    ALTER TABLE organization_members
    ADD CONSTRAINT fk_mem_location
      FOREIGN KEY (location_id)
      REFERENCES locations(location_id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_mem_location_id ON organization_members(location_id);
