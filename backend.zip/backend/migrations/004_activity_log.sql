CREATE TABLE IF NOT EXISTS activity_log (
    log_id                  BIGSERIAL PRIMARY KEY,
    actor_id                BIGINT REFERENCES users(user_id) ON DELETE SET NULL,
    actor_role_key          VARCHAR(50) NOT NULL,
    context_organization_id BIGINT REFERENCES organizations(organization_id) ON DELETE SET NULL,
    target_type             VARCHAR(40) NOT NULL,
    target_id               BIGINT,
    action                  VARCHAR(60) NOT NULL,
    action_category         VARCHAR(30) NOT NULL,
    action_subtype          VARCHAR(60),
    description             TEXT,
    old_values              JSONB,
    new_values              JSONB,
    ip_address              INET,
    user_agent              TEXT,
    occurred_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_successful           BOOLEAN NOT NULL DEFAULT TRUE,
    status                  VARCHAR(20) NOT NULL DEFAULT 'success'
      CHECK (status IN ('success', 'failed', 'denied'))
);

ALTER TABLE activity_log
  ALTER COLUMN actor_id DROP NOT NULL;

CREATE INDEX IF NOT EXISTS idx_activity_log_occurred_at
  ON activity_log (occurred_at DESC);

CREATE INDEX IF NOT EXISTS idx_activity_log_actor_id
  ON activity_log (actor_id);

CREATE INDEX IF NOT EXISTS idx_activity_log_context_org
  ON activity_log (context_organization_id);

CREATE INDEX IF NOT EXISTS idx_activity_log_action
  ON activity_log (action);
