-- =====================================================================
-- 1. Lookup / Master Tables (small tables � minimal indexing needed)
-- =====================================================================
CREATE TABLE roles (
    role_id BIGSERIAL PRIMARY KEY,
    role_key VARCHAR(50) NOT NULL UNIQUE,
    role_name VARCHAR(100) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE plans (
    plan_id BIGSERIAL PRIMARY KEY,
    plan_key VARCHAR(50) NOT NULL UNIQUE,
    plan_name VARCHAR(100) NOT NULL,
    price DECIMAL(12, 2) NOT NULL DEFAULT 0,
    interval_days INTEGER NOT NULL,
    max_users INTEGER NOT NULL DEFAULT 10,
    max_storage_mb BIGINT NOT NULL DEFAULT 500,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE languages (
    language_id BIGSERIAL PRIMARY KEY,
    language_code VARCHAR(10) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    native_name VARCHAR(100) NOT NULL,
    direction VARCHAR(3) NOT NULL DEFAULT 'ltr' CHECK (direction IN ('ltr', 'rtl')),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE timezones (
    timezone_id BIGSERIAL PRIMARY KEY,
    timezone_code VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    utc_offset VARCHAR(10) NOT NULL,
    country_code CHAR(2),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE platforms (
    platform_id BIGSERIAL PRIMARY KEY,
    platform_key VARCHAR(80) NOT NULL UNIQUE,
    platform_name VARCHAR(100) NOT NULL,
    category VARCHAR(20) NOT NULL DEFAULT 'other' CHECK (category IN ('browser', 'os', 'device', 'other')),
    icon_class VARCHAR(100),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE message_menu_items (
    menu_item_id BIGSERIAL PRIMARY KEY,
    menu_key VARCHAR(50) NOT NULL UNIQUE,
    label VARCHAR(100) NOT NULL,
    default_status VARCHAR(20) NOT NULL DEFAULT 'show' CHECK (default_status IN ('show', 'hide', 'disable')),
    scope VARCHAR(20) NOT NULL DEFAULT 'any' CHECK (scope IN ('any', 'self', 'admin')),
    tone VARCHAR(20) DEFAULT 'normal' CHECK (tone IN ('normal', 'danger', 'warning', 'info')),
    icon_class VARCHAR(100),
    display_order SMALLINT NOT NULL DEFAULT 10,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =====================================================================
-- 2. Organization & Membership
-- =====================================================================
CREATE TABLE organizations (
    organization_id BIGSERIAL PRIMARY KEY,
    org_key VARCHAR(80) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    subdomain VARCHAR(100) NOT NULL UNIQUE,
    custom_domain VARCHAR(255) UNIQUE,
    owner_id BIGINT NOT NULL,
    language_id BIGINT NOT NULL DEFAULT 1,
    timezone_id BIGINT NOT NULL DEFAULT 1,
    logo_url TEXT,
    storage_used_mb BIGINT NOT NULL DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'archived')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_org_owner FOREIGN KEY (owner_id) REFERENCES users(user_id) ON DELETE RESTRICT,
    CONSTRAINT fk_org_language FOREIGN KEY (language_id) REFERENCES languages(language_id),
    CONSTRAINT fk_org_timezone FOREIGN KEY (timezone_id) REFERENCES timezones(timezone_id)
);

CREATE INDEX idx_org_owner_id ON organizations(owner_id);

CREATE INDEX idx_org_subdomain ON organizations(subdomain);

CREATE TABLE organization_members (
    membership_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    role_id BIGINT NOT NULL,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'invited', 'suspended', 'left')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_org_user UNIQUE (organization_id, user_id),
    CONSTRAINT fk_mem_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_mem_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_mem_role FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

CREATE INDEX idx_mem_organization_id ON organization_members(organization_id);

CREATE INDEX idx_mem_user_id ON organization_members(user_id);

CREATE INDEX idx_mem_status ON organization_members(status);

CREATE TABLE subscriptions (
    subscription_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    plan_id BIGINT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'active' CHECK (
        status IN (
            'active',
            'trial',
            'expired',
            'cancelled',
            'grace'
        )
    ),
    start_date DATE NOT NULL,
    end_date DATE,
    max_users INTEGER NOT NULL,
    max_storage_mb BIGINT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_sub_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_sub_plan FOREIGN KEY (plan_id) REFERENCES plans(plan_id)
);

CREATE INDEX idx_sub_org_id ON subscriptions(organization_id);

CREATE INDEX idx_sub_status ON subscriptions(status);

CREATE TABLE payment_history (
    payment_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    subscription_id BIGINT,
    plan_id BIGINT,
    amount DECIMAL(12, 2) NOT NULL,
    payment_date TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    payment_status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (
        payment_status IN ('pending', 'completed', 'failed', 'refunded')
    ),
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    transaction_id VARCHAR(100),
    payment_method VARCHAR(50),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_pay_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id),
    CONSTRAINT fk_pay_sub FOREIGN KEY (subscription_id) REFERENCES subscriptions(subscription_id),
    CONSTRAINT fk_pay_plan FOREIGN KEY (plan_id) REFERENCES plans(plan_id)
);

CREATE INDEX idx_pay_org_id ON payment_history(organization_id);

CREATE INDEX idx_pay_payment_date ON payment_history(payment_date);

-- =====================================================================
-- 3. User & Security
-- =====================================================================
CREATE TABLE users (
    user_id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    profile_url TEXT,
    mobile VARCHAR(20),
    is_platform_admin BOOLEAN NOT NULL DEFAULT FALSE,
    is_global_member BOOLEAN NOT NULL DEFAULT FALSE,
    email_verified_at TIMESTAMPTZ,
    mobile_verified_at TIMESTAMPTZ,
    last_login_at TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'suspended', 'invited', 'archived')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);

CREATE INDEX idx_users_status ON users(status);

CREATE INDEX idx_users_last_login ON users(last_login_at);

CREATE TABLE user_devices (
    device_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    device_name VARCHAR(120),
    device_type VARCHAR(20) NOT NULL DEFAULT 'other' CHECK (
        device_type IN ('mobile', 'desktop', 'tablet', 'other')
    ),
    ip_address VARCHAR(45) NOT NULL,
    user_agent TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    accuracy_radius INTEGER,
    country VARCHAR(100),
    city VARCHAR(100),
    last_active_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    is_trusted BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'logged_out', 'suspicious', 'blocked')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_device_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE INDEX idx_device_user_id ON user_devices(user_id);

CREATE INDEX idx_device_status ON user_devices(status);

CREATE INDEX idx_device_last_active ON user_devices(last_active_at);

CREATE TABLE user_sessions (
    session_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    organization_id BIGINT,
    refresh_token_hash VARCHAR(255) NOT NULL,
    user_agent TEXT,
    ip_address INET,
    device_id BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
    CONSTRAINT fk_sess_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_sess_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE
    SET
        NULL,
        CONSTRAINT fk_sess_device FOREIGN KEY (device_id) REFERENCES user_devices(device_id) ON DELETE
    SET
        NULL
);

CREATE INDEX idx_sess_user_id ON user_sessions(user_id);

CREATE INDEX idx_sess_org_id ON user_sessions(organization_id);

CREATE INDEX idx_sess_status ON user_sessions(status);

CREATE INDEX idx_sess_expires_at ON user_sessions(expires_at);

CREATE INDEX idx_sess_token_hash ON user_sessions(refresh_token_hash);

CREATE TABLE otp_verifications (
    otp_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT,
    organization_id BIGINT,
    identifier VARCHAR(255) NOT NULL,
    type VARCHAR(10) NOT NULL CHECK (type IN ('email', 'phone')),
    otp_code VARCHAR(6) NOT NULL,
    purpose VARCHAR(50) NOT NULL DEFAULT 'verification',
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (
        status IN ('pending', 'verified', 'expired', 'failed')
    ),
    attempt_count SMALLINT NOT NULL DEFAULT 0,
    max_attempts SMALLINT NOT NULL DEFAULT 5,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    verified_at TIMESTAMPTZ,
    ip_address VARCHAR(45),
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT fk_otp_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id)
);

CREATE INDEX idx_otp_identifier ON otp_verifications(identifier);

CREATE INDEX idx_otp_status ON otp_verifications(status);

CREATE INDEX idx_otp_expires_at ON otp_verifications(expires_at);

-- =====================================================================
-- 4. Organization Controls & Restrictions
-- =====================================================================
CREATE TABLE organization_controls (
    control_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    feature_key VARCHAR(50) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    time_limit_minutes INTEGER,
    allowed_roles JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_control_feature UNIQUE (organization_id, feature_key),
    CONSTRAINT fk_ctrl_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE
);

CREATE INDEX idx_ctrl_org_id ON organization_controls(organization_id);

CREATE TABLE organization_ip_restrictions (
    restriction_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_ip_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE
);

CREATE INDEX idx_ip_org_id ON organization_ip_restrictions(organization_id);

CREATE TABLE organization_platform_restrictions (
    restriction_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    platform_id BIGINT NOT NULL,
    restriction_type VARCHAR(10) NOT NULL CHECK (restriction_type IN ('allow', 'block')),
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_plat_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_plat_platform FOREIGN KEY (platform_id) REFERENCES platforms(platform_id)
);

CREATE INDEX idx_plat_org_id ON organization_platform_restrictions(organization_id);

CREATE TABLE organization_message_menu_permissions (
    permission_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    menu_item_id BIGINT NOT NULL,
    permission_type VARCHAR(20) NOT NULL DEFAULT 'show' CHECK (permission_type IN ('show', 'hide', 'disable')),
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_menuperm_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_menuperm_item FOREIGN KEY (menu_item_id) REFERENCES message_menu_items(menu_item_id)
);

CREATE INDEX idx_menuperm_org_id ON organization_message_menu_permissions(organization_id);

-- =====================================================================
-- 5. Organization Structure
-- =====================================================================
CREATE TABLE departments (
    department_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    name VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_dept_org_name UNIQUE (organization_id, name),
    CONSTRAINT fk_dept_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE
);

CREATE INDEX idx_dept_org_id ON departments(organization_id);

CREATE TABLE designations (
    designation_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    department_id BIGINT NOT NULL,
    name VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_desig_org_name UNIQUE (organization_id, name),
    CONSTRAINT fk_desig_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_desig_dept FOREIGN KEY (department_id) REFERENCES departments(department_id) ON DELETE CASCADE
);

CREATE INDEX idx_desig_org_id ON designations(organization_id);

CREATE TABLE locations (
    location_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    label VARCHAR(100) NOT NULL,
    country VARCHAR(100) NOT NULL DEFAULT 'India',
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_loc_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE
);

CREATE INDEX idx_loc_org_id ON locations(organization_id);

-- =====================================================================
-- 6. Groups / Channels
-- =====================================================================
CREATE TABLE groups (
    group_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    group_name VARCHAR(100) NOT NULL,
    group_description TEXT,
    group_image TEXT,
    created_by BIGINT NOT NULL,
    is_airtime BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'inactive', 'archived', 'deleted')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_group_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_group_creator FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE INDEX idx_group_org_id ON groups(organization_id);

CREATE INDEX idx_group_status ON groups(status);

CREATE TABLE group_members (
    group_member_id BIGSERIAL PRIMARY KEY,
    group_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    is_admin BOOLEAN NOT NULL DEFAULT FALSE,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    organization_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'left', 'kicked', 'banned')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_group_user UNIQUE (group_id, user_id),
    CONSTRAINT fk_gmem_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE,
    CONSTRAINT fk_gmem_user FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT fk_gmem_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id)
);

CREATE INDEX idx_gmem_group_id ON group_members(group_id);

CREATE INDEX idx_gmem_user_id ON group_members(user_id);

CREATE TABLE group_permissions (
    permission_id BIGSERIAL PRIMARY KEY,
    group_id BIGINT NOT NULL,
    feature_key VARCHAR(50) NOT NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    allowed_roles JSONB,
    time_limit_minutes INTEGER,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_gperm_feature UNIQUE (group_id, feature_key),
    CONSTRAINT fk_gperm_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE
);

CREATE INDEX idx_gperm_group_id ON group_permissions(group_id);

CREATE TABLE group_timeline (
    timeline_id BIGSERIAL PRIMARY KEY,
    group_id BIGINT NOT NULL,
    actor_user_id BIGINT NOT NULL,
    target_user_id BIGINT,
    event_type VARCHAR(50) NOT NULL,
    event_description TEXT NOT NULL,
    organization_id BIGINT NOT NULL,
    event_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status VARCHAR(20) NOT NULL DEFAULT 'visible' CHECK (status IN ('visible', 'hidden', 'deleted')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_tline_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE,
    CONSTRAINT fk_tline_actor FOREIGN KEY (actor_user_id) REFERENCES users(user_id),
    CONSTRAINT fk_tline_target FOREIGN KEY (target_user_id) REFERENCES users(user_id),
    CONSTRAINT fk_tline_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id)
);

CREATE INDEX idx_tline_group_id ON group_timeline(group_id);

CREATE INDEX idx_tline_event_at ON group_timeline(event_at);

-- =====================================================================
-- 7. Messaging (1:1 & Group)
-- =====================================================================
CREATE TABLE messages (
    message_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    sender_id BIGINT NOT NULL,
    receiver_id BIGINT NOT NULL,
    message TEXT,
    message_type VARCHAR(20) NOT NULL DEFAULT 'text' CHECK (
        message_type IN ('text', 'file', 'link', 'code', 'system')
    ),
    message_metadata JSONB,
    send_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    read_time TIMESTAMPTZ,
    edit_time TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_msg_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id),
    CONSTRAINT fk_msg_sender FOREIGN KEY (sender_id) REFERENCES users(user_id),
    CONSTRAINT fk_msg_receiver FOREIGN KEY (receiver_id) REFERENCES users(user_id)
);

CREATE INDEX idx_msg_org_sender_time ON messages(organization_id, sender_id, send_time DESC);

CREATE INDEX idx_msg_org_receiver_time ON messages(organization_id, receiver_id, send_time DESC);

CREATE INDEX idx_messages_fts ON messages USING GIN (to_tsvector('english', message));

CREATE TABLE message_files (
    file_id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_file_msg FOREIGN KEY (message_id) REFERENCES messages(message_id) ON DELETE CASCADE
);

CREATE INDEX idx_file_msg_id ON message_files(message_id);

CREATE TABLE message_actions (
    action_id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    action_type VARCHAR(30) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_act_msg FOREIGN KEY (message_id) REFERENCES messages(message_id) ON DELETE CASCADE,
    CONSTRAINT fk_act_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE INDEX idx_act_msg_id ON message_actions(message_id);

CREATE INDEX idx_act_user_id ON message_actions(user_id);

-- =============================================
-- Group Messages & Related Tables
-- =============================================
CREATE TABLE group_messages (
    group_message_id BIGSERIAL PRIMARY KEY,
    organization_id BIGINT NOT NULL,
    group_id BIGINT NOT NULL,
    sender_id BIGINT NOT NULL,
    message_type VARCHAR(20) NOT NULL DEFAULT 'text',
    message TEXT,
    message_metadata JSONB,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_gmsg_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id),
    CONSTRAINT fk_gmsg_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE,
    CONSTRAINT fk_gmsg_sender FOREIGN KEY (sender_id) REFERENCES users(user_id)
);

CREATE INDEX idx_gmsg_group_time ON group_messages (group_id, created_at DESC);

CREATE INDEX idx_gmsg_org_group_time ON group_messages (organization_id, group_id, created_at DESC);

CREATE INDEX idx_group_messages_fts ON group_messages USING GIN (to_tsvector('english', message));

CREATE TABLE group_message_recipients (
    recipient_id BIGSERIAL PRIMARY KEY,
    group_message_id BIGINT NOT NULL,
    group_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    delivery_status VARCHAR(20) NOT NULL DEFAULT 'sent' CHECK (delivery_status IN ('sent', 'delivered', 'read')),
    delivered_at TIMESTAMPTZ,
    read_at TIMESTAMPTZ,
    CONSTRAINT uk_recipient UNIQUE (group_message_id, user_id),
    CONSTRAINT fk_recip_msg FOREIGN KEY (group_message_id) REFERENCES group_messages(group_message_id) ON DELETE CASCADE,
    CONSTRAINT fk_recip_group FOREIGN KEY (group_id) REFERENCES groups(group_id),
    CONSTRAINT fk_recip_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE INDEX idx_recip_msg_id ON group_message_recipients(group_message_id);

CREATE INDEX idx_recip_user_id ON group_message_recipients(user_id);

CREATE TABLE group_message_files (
    file_id BIGSERIAL PRIMARY KEY,
    group_message_id BIGINT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    file_size BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_gfile_msg FOREIGN KEY (group_message_id) REFERENCES group_messages(group_message_id) ON DELETE CASCADE
);

CREATE INDEX idx_gfile_msg_id ON group_message_files(group_message_id);

CREATE TABLE group_message_actions (
    action_id BIGSERIAL PRIMARY KEY,
    group_message_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    action_type VARCHAR(30) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_gact_msg FOREIGN KEY (group_message_id) REFERENCES group_messages(group_message_id) ON DELETE CASCADE,
    CONSTRAINT fk_gact_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE INDEX idx_gact_msg_id ON group_message_actions(group_message_id);

CREATE INDEX idx_gact_user_id ON group_message_actions(user_id);

-- =============================================
-- Group Polls & Voting
-- =============================================
CREATE TABLE group_polls (
    poll_id BIGSERIAL PRIMARY KEY,
    group_message_id BIGINT NOT NULL,
    group_id BIGINT NOT NULL,
    question TEXT NOT NULL,
    poll_type VARCHAR(20) NOT NULL DEFAULT 'single' CHECK (poll_type IN ('single', 'multiple')),
    show_results_before_vote BOOLEAN NOT NULL DEFAULT FALSE,
    ends_at TIMESTAMPTZ,
    end_permission VARCHAR(30) NOT NULL DEFAULT 'creator_admin' CHECK (
        end_permission IN ('creator_only', 'creator_admin', 'admin')
    ),
    created_by BIGINT NOT NULL,
    ended_by BIGINT,
    ended_at TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended', 'deleted')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_poll_msg FOREIGN KEY (group_message_id) REFERENCES group_messages(group_message_id) ON DELETE CASCADE,
    CONSTRAINT fk_poll_group FOREIGN KEY (group_id) REFERENCES groups(group_id),
    CONSTRAINT fk_poll_creator FOREIGN KEY (created_by) REFERENCES users(user_id),
    CONSTRAINT fk_poll_ender FOREIGN KEY (ended_by) REFERENCES users(user_id)
);

CREATE INDEX idx_poll_group_msg ON group_polls(group_message_id);

CREATE TABLE group_poll_options (
    option_id BIGSERIAL PRIMARY KEY,
    poll_id BIGINT NOT NULL,
    option_text TEXT NOT NULL,
    vote_count INTEGER NOT NULL DEFAULT 0,
    order_no SMALLINT NOT NULL DEFAULT 1,
    CONSTRAINT fk_opt_poll FOREIGN KEY (poll_id) REFERENCES group_polls(poll_id) ON DELETE CASCADE
);

CREATE INDEX idx_opt_poll_id ON group_poll_options(poll_id);

CREATE TABLE group_poll_votes (
    vote_id BIGSERIAL PRIMARY KEY,
    poll_id BIGINT NOT NULL,
    option_id BIGINT NOT NULL,
    user_id BIGINT NOT NULL,
    voted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_poll_user_option UNIQUE (poll_id, user_id, option_id),
    CONSTRAINT fk_vote_poll FOREIGN KEY (poll_id) REFERENCES group_polls(poll_id) ON DELETE CASCADE,
    CONSTRAINT fk_vote_option FOREIGN KEY (option_id) REFERENCES group_poll_options(option_id) ON DELETE CASCADE,
    CONSTRAINT fk_vote_user FOREIGN KEY (user_id) REFERENCES users(user_id)
);

CREATE INDEX idx_vote_poll_id ON group_poll_votes(poll_id);

CREATE INDEX idx_vote_user_id ON group_poll_votes(user_id);

-- =============================================
-- Activity Log
-- =============================================
CREATE TABLE activity_log (
    log_id BIGSERIAL PRIMARY KEY,
    actor_id BIGINT NOT NULL REFERENCES users(user_id) ON DELETE
    SET
        NULL,
        actor_role_key VARCHAR(50) NOT NULL,
        context_organization_id BIGINT REFERENCES organizations(organization_id) ON DELETE
    SET
        NULL,
        target_type VARCHAR(40) NOT NULL,
        target_id BIGINT,
        action VARCHAR(60) NOT NULL,
        action_category VARCHAR(30) NOT NULL,
        action_subtype VARCHAR(60),
        description TEXT,
        old_values JSONB,
        new_values JSONB,
        ip_address INET,
        user_agent TEXT,
        occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        is_successful BOOLEAN NOT NULL DEFAULT TRUE,
        status VARCHAR(20) DEFAULT 'success' CHECK (status IN ('success', 'failed', 'denied'))
);

CREATE INDEX idx_activity_org_time ON activity_log (context_organization_id, occurred_at DESC);

CREATE INDEX idx_activity_actor_time ON activity_log (actor_id, occurred_at DESC);

CREATE INDEX idx_activity_target ON activity_log (target_type, target_id);

CREATE INDEX idx_activity_action ON activity_log (action);

CREATE INDEX idx_activity_occurred ON activity_log (occurred_at DESC);

-- User Sessions for Refresh Tokens
CREATE TABLE user_sessions (
    session_id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    organization_id BIGINT,
    refresh_token_hash VARCHAR(255) NOT NULL,
    user_agent TEXT,
    ip_address INET,
    device_id BIGINT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL,
    revoked_at TIMESTAMPTZ,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
    CONSTRAINT fk_sess_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_sess_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE
    SET
        NULL,
        CONSTRAINT fk_sess_device FOREIGN KEY (device_id) REFERENCES user_devices(device_id) ON DELETE
    SET
        NULL
);

CREATE INDEX idx_sess_user_id ON user_sessions(user_id);

CREATE INDEX idx_sess_org_id ON user_sessions(organization_id);

CREATE INDEX idx_sess_status ON user_sessions(status);

CREATE INDEX idx_sess_expires_at ON user_sessions(expires_at);

CREATE INDEX idx_sess_token_hash ON user_sessions(refresh_token_hash);