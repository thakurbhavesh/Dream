CREATE TABLE IF NOT EXISTS organization_message_menu_permissions (
    permission_id       BIGSERIAL PRIMARY KEY,
    organization_id     BIGINT NOT NULL,
    menu_item_id        BIGINT NOT NULL,
    permission_type     VARCHAR(20) NOT NULL DEFAULT 'show' CHECK (permission_type IN ('show','hide','disable')),
    note                TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_menuperm_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_menuperm_item FOREIGN KEY (menu_item_id) REFERENCES message_menu_items(menu_item_id)
);

CREATE INDEX IF NOT EXISTS idx_menuperm_org_id
  ON organization_message_menu_permissions (organization_id);

ALTER TABLE organization_message_menu_permissions
  ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'active';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'chk_menuperm_status'
  ) THEN
    ALTER TABLE organization_message_menu_permissions
      ADD CONSTRAINT chk_menuperm_status
      CHECK (status IN ('active', 'inactive'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_menuperm_org_status
  ON organization_message_menu_permissions (organization_id, status);

