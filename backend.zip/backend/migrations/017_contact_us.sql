CREATE TABLE IF NOT EXISTS contact_us_requests (
    contact_request_id   BIGSERIAL PRIMARY KEY,
    name                 VARCHAR(120) NOT NULL,
    country_code         VARCHAR(10) NOT NULL DEFAULT '+91',
    mobile_number        VARCHAR(30) NOT NULL,
    email_address        VARCHAR(255) NOT NULL,
    company_name         VARCHAR(150) NOT NULL,
    total_users          INTEGER NOT NULL CHECK (total_users > 0),
    requirement_details  TEXT,
    status               VARCHAR(20) NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'reviewed', 'closed')),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_contact_us_requests_created_at
  ON contact_us_requests (created_at DESC);

CREATE INDEX IF NOT EXISTS idx_contact_us_requests_status
  ON contact_us_requests (status);

CREATE INDEX IF NOT EXISTS idx_contact_us_requests_email
  ON contact_us_requests (LOWER(email_address));

CREATE INDEX IF NOT EXISTS idx_contact_us_requests_mobile
  ON contact_us_requests (mobile_number);
