-- Additional hot-path indexes for frequently used list APIs.

-- Org users list: organization filter + joined_at sort.
CREATE INDEX IF NOT EXISTS idx_org_members_org_joined_desc
  ON organization_members (organization_id, joined_at DESC);

-- Global access list: org filter + created sort.
CREATE INDEX IF NOT EXISTS idx_global_access_org_created_desc
  ON global_access (org_id, created_at DESC);

-- Org structure lists: organization filter + descending id sort.
CREATE INDEX IF NOT EXISTS idx_departments_org_id_desc
  ON departments (organization_id, department_id DESC);

CREATE INDEX IF NOT EXISTS idx_designations_org_id_desc
  ON designations (organization_id, designation_id DESC);

CREATE INDEX IF NOT EXISTS idx_locations_org_id_desc
  ON locations (organization_id, location_id DESC);
