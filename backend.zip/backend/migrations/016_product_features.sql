CREATE TABLE IF NOT EXISTS feature_categories (
    feature_category_id BIGSERIAL PRIMARY KEY,
    category_key        VARCHAR(60) NOT NULL UNIQUE,
    category_label      VARCHAR(100) NOT NULL,
    display_order       SMALLINT NOT NULL DEFAULT 10,
    status              VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_feature_categories_status_order
  ON feature_categories (status, display_order, feature_category_id);

CREATE TABLE IF NOT EXISTS feature_items (
    feature_item_id      BIGSERIAL PRIMARY KEY,
    feature_category_id  BIGINT NOT NULL,
    title                VARCHAR(200) NOT NULL,
    description          TEXT,
    icon_url             TEXT,
    display_order        SMALLINT NOT NULL DEFAULT 10,
    status               VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_feature_items_category
      FOREIGN KEY (feature_category_id) REFERENCES feature_categories(feature_category_id) ON DELETE CASCADE,
    CONSTRAINT uk_feature_item_title_per_category
      UNIQUE (feature_category_id, title)
);

CREATE INDEX IF NOT EXISTS idx_feature_items_category_id
  ON feature_items (feature_category_id);

CREATE INDEX IF NOT EXISTS idx_feature_items_status_order
  ON feature_items (status, display_order, feature_item_id);

INSERT INTO feature_categories (category_key, category_label, display_order, status)
VALUES
  ('messaging', 'MESSAGING', 1, 'active'),
  ('group', 'GROUP', 2, 'active'),
  ('audio_video', 'AUDIO & VIDEO', 3, 'active'),
  ('collaboration', 'COLLABORATION', 4, 'active'),
  ('productivity', 'PRODUCTIVITY', 5, 'active'),
  ('filters', 'FILTERS', 6, 'active'),
  ('security', 'SECURITY', 7, 'active'),
  ('admin', 'ADMIN', 8, 'active'),
  ('ai_features', 'AI FEATURES', 9, 'active')
ON CONFLICT (category_key) DO UPDATE
SET
  category_label = EXCLUDED.category_label,
  display_order = EXCLUDED.display_order,
  status = EXCLUDED.status,
  updated_at = NOW();

INSERT INTO feature_items (
  feature_category_id,
  title,
  description,
  display_order,
  status
)
SELECT
  fc.feature_category_id,
  seed.title,
  seed.description,
  seed.display_order,
  'active'
FROM feature_categories fc
JOIN (
  VALUES
    (
      'One-On-One Messaging',
      'A 1:1 message is brief and to the point! Converse and share your work details with your co-workers instantly',
      1
    ),
    (
      'Audio Messaging',
      'Voice notes are fun and fast! Record your work update in an audio message, preview it, and then share it across 1:1 or group chats.',
      2
    ),
    (
      'Forkout',
      'This bulk messaging ability allows you to send the message or attachment to a high volume of users or groups in just one go.',
      3
    )
) AS seed(title, description, display_order)
  ON fc.category_key = 'messaging'
ON CONFLICT (feature_category_id, title) DO UPDATE
SET
  description = EXCLUDED.description,
  display_order = EXCLUDED.display_order,
  status = EXCLUDED.status,
  updated_at = NOW();
