-- Performance indexes for group members and group timeline listing APIs.
CREATE INDEX IF NOT EXISTS idx_gmem_org_status_group_desc ON group_members (organization_id, status, group_member_id DESC);

CREATE INDEX IF NOT EXISTS idx_tline_org_status_event_desc ON group_timeline (organization_id, status, event_at DESC);

CREATE INDEX IF NOT EXISTS idx_tline_group_type_event_desc ON group_timeline (group_id, event_type, event_at DESC);