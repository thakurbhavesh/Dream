CREATE TABLE IF NOT EXISTS organization_ip_restrictions (
    restriction_id      BIGSERIAL PRIMARY KEY,
    organization_id     BIGINT NOT NULL,
    ip_address          VARCHAR(45) NOT NULL,
    note                TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_ip_org
      FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE
);

ALTER TABLE organization_ip_restrictions
  ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'active';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'chk_organization_ip_restrictions_status'
  ) THEN
    ALTER TABLE organization_ip_restrictions
      ADD CONSTRAINT chk_organization_ip_restrictions_status
      CHECK (status IN ('active', 'inactive'));
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uk_org_ip_restriction
  ON organization_ip_restrictions(organization_id, ip_address);

CREATE INDEX IF NOT EXISTS idx_ip_org_id
  ON organization_ip_restrictions(organization_id);

CREATE INDEX IF NOT EXISTS idx_ip_org_status
  ON organization_ip_restrictions(organization_id, status);

CREATE TABLE IF NOT EXISTS organization_platform_restrictions (
    restriction_id      BIGSERIAL PRIMARY KEY,
    organization_id     BIGINT NOT NULL,
    platform_id         BIGINT NOT NULL,
    restriction_type    VARCHAR(10) NOT NULL CHECK (restriction_type IN ('allow', 'block')),
    note                TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_plat_org
      FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_plat_platform
      FOREIGN KEY (platform_id) REFERENCES platforms(platform_id)
);

ALTER TABLE organization_platform_restrictions
  ADD COLUMN IF NOT EXISTS status VARCHAR(20) NOT NULL DEFAULT 'active';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'chk_organization_platform_restrictions_status'
  ) THEN
    ALTER TABLE organization_platform_restrictions
      ADD CONSTRAINT chk_organization_platform_restrictions_status
      CHECK (status IN ('active', 'inactive'));
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS uk_org_platform_restriction
  ON organization_platform_restrictions(organization_id, platform_id);

CREATE INDEX IF NOT EXISTS idx_plat_org_id
  ON organization_platform_restrictions(organization_id);

CREATE INDEX IF NOT EXISTS idx_plat_org_status
  ON organization_platform_restrictions(organization_id, status);
