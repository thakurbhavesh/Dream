ALTER TABLE organization_members
ADD COLUMN IF NOT EXISTS department_id BIGINT,
ADD COLUMN IF NOT EXISTS designation_id BIGINT;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_mem_department'
  ) THEN
    ALTER TABLE organization_members
    ADD CONSTRAINT fk_mem_department
      FOREIGN KEY (department_id)
      REFERENCES departments(department_id)
      ON DELETE SET NULL;
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_mem_designation'
  ) THEN
    ALTER TABLE organization_members
    ADD CONSTRAINT fk_mem_designation
      FOREIGN KEY (designation_id)
      REFERENCES designations(designation_id)
      ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_mem_department_id ON organization_members(department_id);
CREATE INDEX IF NOT EXISTS idx_mem_designation_id ON organization_members(designation_id);
