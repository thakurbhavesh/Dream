DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'fk_global_access_allow_user_org_member'
  ) THEN
    ALTER TABLE global_access
    ADD CONSTRAINT fk_global_access_allow_user_org_member
      FOREIGN KEY (org_id, allow_user_id)
      REFERENCES organization_members (organization_id, user_id)
      ON DELETE CASCADE
      NOT VALID;
  END IF;
END $$;
