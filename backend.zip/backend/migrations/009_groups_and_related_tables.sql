CREATE TABLE IF NOT EXISTS groups (
    group_id            BIGSERIAL PRIMARY KEY,
    organization_id     BIGINT NOT NULL,
    group_name          VARCHAR(100) NOT NULL,
    group_description   TEXT,
    group_image         TEXT,
    created_by          BIGINT NOT NULL,
    is_airtime          BOOLEAN NOT NULL DEFAULT FALSE,
    status              VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','archived','deleted')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_group_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id) ON DELETE CASCADE,
    CONSTRAINT fk_group_creator FOREIGN KEY (created_by) REFERENCES users(user_id)
);

CREATE INDEX IF NOT EXISTS idx_group_org_id ON groups(organization_id);
CREATE INDEX IF NOT EXISTS idx_group_status ON groups(status);
CREATE INDEX IF NOT EXISTS idx_group_org_status_created_desc ON groups(organization_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS group_members (
    group_member_id     BIGSERIAL PRIMARY KEY,
    group_id            BIGINT NOT NULL,
    user_id             BIGINT NOT NULL,
    is_admin            BOOLEAN NOT NULL DEFAULT FALSE,
    joined_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    organization_id     BIGINT NOT NULL,
    status              VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','left','kicked','banned')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_group_user UNIQUE (group_id, user_id),
    CONSTRAINT fk_gmem_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE,
    CONSTRAINT fk_gmem_user FOREIGN KEY (user_id) REFERENCES users(user_id),
    CONSTRAINT fk_gmem_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id)
);

CREATE INDEX IF NOT EXISTS idx_gmem_group_id ON group_members(group_id);
CREATE INDEX IF NOT EXISTS idx_gmem_user_id ON group_members(user_id);
CREATE INDEX IF NOT EXISTS idx_gmem_group_status ON group_members(group_id, status);

CREATE TABLE IF NOT EXISTS group_permissions (
    permission_id       BIGSERIAL PRIMARY KEY,
    group_id            BIGINT NOT NULL,
    feature_key         VARCHAR(50) NOT NULL,
    enabled             BOOLEAN NOT NULL DEFAULT TRUE,
    allowed_roles       JSONB,
    time_limit_minutes  INTEGER,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT uk_gperm_feature UNIQUE (group_id, feature_key),
    CONSTRAINT fk_gperm_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_gperm_group_id ON group_permissions(group_id);

CREATE TABLE IF NOT EXISTS group_timeline (
    timeline_id         BIGSERIAL PRIMARY KEY,
    group_id            BIGINT NOT NULL,
    actor_user_id       BIGINT NOT NULL,
    target_user_id      BIGINT,
    event_type          VARCHAR(50) NOT NULL,
    event_description   TEXT NOT NULL,
    organization_id     BIGINT NOT NULL,
    event_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status              VARCHAR(20) NOT NULL DEFAULT 'visible' CHECK (status IN ('visible','hidden','deleted')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_tline_group FOREIGN KEY (group_id) REFERENCES groups(group_id) ON DELETE CASCADE,
    CONSTRAINT fk_tline_actor FOREIGN KEY (actor_user_id) REFERENCES users(user_id),
    CONSTRAINT fk_tline_target FOREIGN KEY (target_user_id) REFERENCES users(user_id),
    CONSTRAINT fk_tline_org FOREIGN KEY (organization_id) REFERENCES organizations(organization_id)
);

CREATE INDEX IF NOT EXISTS idx_tline_group_id ON group_timeline(group_id);
CREATE INDEX IF NOT EXISTS idx_tline_event_at ON group_timeline(event_at);
CREATE INDEX IF NOT EXISTS idx_tline_group_event_desc ON group_timeline(group_id, event_at DESC);
