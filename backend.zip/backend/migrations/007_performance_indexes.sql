-- Performance indexes for frequently used filters/sorts in auth, users, global access, and activity logs.

CREATE INDEX IF NOT EXISTS idx_users_lower_email
  ON users (LOWER(email));

CREATE INDEX IF NOT EXISTS idx_mem_org_user_status
  ON organization_members (organization_id, user_id, status);

CREATE INDEX IF NOT EXISTS idx_mem_org_status_joined_desc
  ON organization_members (organization_id, status, joined_at DESC);

CREATE INDEX IF NOT EXISTS idx_sub_org_created_desc
  ON subscriptions (organization_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_device_user_last_active_desc
  ON user_devices (user_id, last_active_at DESC);

CREATE INDEX IF NOT EXISTS idx_sess_user_org_created_desc
  ON user_sessions (user_id, organization_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_otp_identifier_type_purpose_created_desc
  ON otp_verifications (LOWER(identifier), type, purpose, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_global_access_org_user_status_created_desc
  ON global_access (org_id, user_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_global_access_org_allow_user_status
  ON global_access (org_id, allow_user_id, status);

CREATE INDEX IF NOT EXISTS idx_activity_log_org_action_time_desc
  ON activity_log (context_organization_id, action, occurred_at DESC);
